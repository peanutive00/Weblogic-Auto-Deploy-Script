/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao;

import hk.com.hkbn.itbss.entity.BillingReplaceEntity;
import hk.com.hkbn.itbss.entity.EOEntity;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import hk.com.hkbn.itbss.entity.Picture;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 *
 * @author itbssvendor01
 */
public interface EquipmentOfferDao {
    
    public List<EOEntity> getResEoByPps(String pps) throws SQLException;
    
    public List<EOEntity> getResEoByPreReg(String preRegCode) throws SQLException;
    
    public EquipmentEntity getEsEquipmentEntity(String imei, String serialNo, String status) throws SQLException;
    
    public String replaceEquip(BillingReplaceEntity billingReplaceEntity) throws SQLException;
    
    public String getServiceNobyImei(String imei) throws SQLException;
 
    public Map<String, Picture> getPictureMap(List<String> itemIdList) throws SQLException;
    
    public Picture getPicture(String itemId) throws SQLException;
    
    public String getDummyItemId() throws SQLException;
    
}
