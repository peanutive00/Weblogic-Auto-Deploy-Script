package hk.com.hkbn.itbss.constants;

/**
 * @description: this is class of response type
 * @author: leon.cheung
 * @create: 23-03-2018
 **/
public class RequestType {

  public static final String ES = "ES";
  public static final String RES = "RES";
  public static final String OTHER = "other";

}
