package hk.com.hkbn.itbss.entity;

/**
 * @description:
 * @author: leon.cheung
 * @create: 25-04-2018
 **/
public class CustomerEntity {

  private String pps;
  private Long cusPriCode;
  private String cusName;
  private String cusStatus;

  public String getPps() {
    return pps;
  }

  public void setPps(String pps) {
    this.pps = pps;
  }

  public Long getCusPriCode() {
    return cusPriCode;
  }

  public void setCusPriCode(Long cusPriCode) {
    this.cusPriCode = cusPriCode;
  }

  public String getCusName() {
    return cusName;
  }

  public void setCusName(String cusName) {
    this.cusName = cusName;
  }

  public String getCusStatus() {
    return cusStatus;
  }

  public void setCusStatus(String cusStatus) {
    this.cusStatus = cusStatus;
  }
}
