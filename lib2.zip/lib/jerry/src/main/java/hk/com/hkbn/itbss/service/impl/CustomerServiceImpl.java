/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.dao.CustomerDao;
import hk.com.hkbn.itbss.dao.impl.CustomerDaoImpl;
import hk.com.hkbn.itbss.entity.CustomerEntity;
import hk.com.hkbn.itbss.service.CustomerService;
import java.sql.SQLException;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;

/**
 * @author itbssvendor02
 */

@Stateless
@LocalBean
public class CustomerServiceImpl implements CustomerService {


  private org.slf4j.Logger _logger = org.slf4j.LoggerFactory
      .getLogger(CustomerServiceImpl.class);

  @Resource
  private EJBContext ctx;

  @Resource(name = "jdbc.hkbn")
  private DataSource ds;

  private CustomerDao dao;

  public CustomerServiceImpl() {

  }

  public CustomerServiceImpl(CustomerDao dao) {
    this.dao = dao;
  }

  @PostConstruct
  private void init() {
    this.dao = new CustomerDaoImpl(ds);
  }

  @Override
  public CustomerEntity getCusInfo(String pps) {
    CustomerEntity customerEntity = null;
    try {
      customerEntity = dao.getCustomer(pps);

    } catch (SQLException e) {
      e.printStackTrace();
    }
    return customerEntity;
  }
}
