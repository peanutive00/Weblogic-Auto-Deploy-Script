/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.EOEntity;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import hk.com.hkbn.itbss.entity.Picture;
import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import javax.ejb.Local;

/**
 *
 * @author itbssvendor01
 */
@Local
public interface EquipmentOfferService {
    
    public List<EOEntity> getResEoByPps(String pps) throws SQLException;
    
    public List<EOEntity> getResEoByPreReg(String preRegCode) throws SQLException;
    
    public List<EquipmentEntity> getEsEoByPps(String pps) throws Exception;
    
    public List<EquipmentEntity> getEsEoByImei(String imei) throws Exception;
    
    public EquipmentEntity getEsEquipment(String imei, String serialNo, String status) throws SQLException;
    
    public String updateEquipment(ReplaceUpdateEntity entity) throws Exception;
 
    public Map<String, Picture> getPictureMap(List<String> itemIdList) throws SQLException;
    
    public Picture getPicture(String itemId) throws SQLException;
    
    public String getDummyItemId() throws SQLException;    
    
}
