package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import javax.ejb.Local;

/**
 * @description:
 * @author: leon.cheung
 * @create: 03-05-2018
 **/
@Local
public interface LogActionService {

  public void createRemarkAction(ReplaceUpdateEntity request);

}
