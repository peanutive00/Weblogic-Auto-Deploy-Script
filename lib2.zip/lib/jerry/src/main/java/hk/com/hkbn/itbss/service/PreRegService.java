/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.PreRegEntity;
import java.sql.SQLException;
import javax.ejb.Local;

/**
 *
 * @author itbssvendor01
 */
@Local
public interface PreRegService {
    
    public PreRegEntity getPreRegInfo(String preRegCode) throws SQLException;
    
}
