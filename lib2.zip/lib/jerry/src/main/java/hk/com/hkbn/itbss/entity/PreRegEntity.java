/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

/**
 *
 * @author itbssvendor01
 */
public class PreRegEntity {

    private String preRegCode;
    private String surname;
    private String givenName;
    private String status;

    public String getPreRegCode() {
        return preRegCode;
    }

    public void setPreRegCode(String preRegCode) {
        this.preRegCode = preRegCode;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
