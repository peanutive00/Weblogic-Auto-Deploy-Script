package hk.com.hkbn.itbss.dao;

import hk.com.hkbn.itbss.entity.CustomerEntity;
import java.sql.SQLException;

/**
 * @description:
 * @author: leon.cheung
 * @create: 25-04-2018
 **/
public interface CustomerDao {

  CustomerEntity getCustomer(String pps) throws SQLException;
}
