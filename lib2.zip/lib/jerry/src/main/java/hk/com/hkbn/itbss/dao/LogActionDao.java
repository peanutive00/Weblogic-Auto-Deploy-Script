package hk.com.hkbn.itbss.dao;

import java.sql.SQLException;

/**
 * @description: ices log
 * @author: leon.cheung
 * @create: 03-05-2018
 **/
public interface LogActionDao {


  String createRemarkAction(Long cusPriCode, int caseCode, String remark, String userName) throws SQLException;

}
