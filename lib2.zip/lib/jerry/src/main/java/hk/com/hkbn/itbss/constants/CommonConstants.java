package hk.com.hkbn.itbss.constants;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;

/**
 * @description:
 * @author: leon.cheung
 * @create: 11-04-2018
 **/
public class CommonConstants {

    public static final String ES = "ES";
    public static final String RES = "RES";
    public static final String CONTENT_TYPE = "application/json";
    
    
    public static final String ES_REF_TYPE = "ES_API";
    
    public static final String FIND_SIM_REF_CODE = "FIND_SIM";
    public static final String REPLACE_SIM_REF_CODE = "REPLACE_SIM";
    public static final String FIND_GLOBAL_PHONE_REF_CODE = "FIND_GLOBAL_PHONE";
    public static final String CHECK_GLOBAL_PHONE_REF_CODE = "CHECK_GLOBAL_PHONE";
    public static final String REPLACE_GLOBAL_PHONE_REF_CODE = "REPLACE_GLOBAL_PHONE";
    public static final String TEMP_ITEM_ID_REF_CODE = "TEMP_ITEM_ID";

    
    public static final String ES_API_BASE_URL = "https://webservicesuat.hkbn.com.hk/esmobile/ws/ucloudlink";

    /**
     * es production link for find old Imei
     * uat is:X
     */
    public static final String FIND_IMEI = "/findImei";
    /**
     * es production link for check new Imei
     * uat is:X
     */
    public static final String CHECK_IMEI = "/checkImei";
    /**
     * es production link for check new Imei.
     * uat is:X
     */
    public static final String UPDATE_IMEI = "/updateImei";

    public static final String ES_API_USER_NAME = "esmobilewsuser";
    public static final String ES_API_PASSWORD = "esmobilewsuser123";

    public static final String ES_AUTH_STRING_ENC = new String(Base64.encodeBase64(
        (CommonConstants.ES_API_USER_NAME + ":" + CommonConstants.ES_API_PASSWORD).getBytes()));
    
    public static final String SUCCESS = "SUCCESS";
    /**
     * means fail
     */
    public static final String CODE_0 = "0";
    /**
     * means success
     */
    public static final String CODE_1 = "1";


    /**
     * charge option key-value
     */
    public static final String chargeOption1Key = "1";
    public static final String chargeOption2Key = "2";
    public static final String chargeOption3Key = "3";
    public static final String chargeOption4Key = "4";

    public static final String chargeOption1Value = "Charge waived(Within 7 Days, for Global Phone only)";
    public static final String chargeOption2Value = "Charge waived(With approval from ESCS)";
    public static final String chargeOption3Value = "Charge in statement(for SIM only)";
    public static final String chargeOption4Value = "Paid(For purchase Global Phone at shop only)";

    public static Map<String, String> chargeOptionMap = new HashMap<String, String>();

    static {
      chargeOptionMap.put(chargeOption1Key, chargeOption1Value);
      chargeOptionMap.put(chargeOption2Key, chargeOption2Value);
      chargeOptionMap.put(chargeOption3Key, chargeOption3Value);
      chargeOptionMap.put(chargeOption4Key, chargeOption4Value);
    }

}
