/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.BrxEomRefCodeEntity;
import java.sql.SQLException;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author itbssvendor01
 */
@Local 
public interface BrxEomRefCodeService {
    
    public List<BrxEomRefCodeEntity> getRefCodeList(String refType) throws SQLException;
    
    public List<BrxEomRefCodeEntity> findAll(BrxEomRefCodeEntity entity) throws SQLException;
    
}
