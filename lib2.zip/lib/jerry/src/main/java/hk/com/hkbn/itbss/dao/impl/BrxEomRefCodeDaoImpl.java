/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.BrxEomRefCodeDao;
import hk.com.hkbn.itbss.entity.BrxEomRefCodeEntity;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author itbssvendor01
 */ 
public class BrxEomRefCodeDaoImpl implements BrxEomRefCodeDao {
    
    private org.slf4j.Logger _logger = org.slf4j.LoggerFactory.getLogger(BrxEomRefCodeDaoImpl.class);
    
    private final DataSource ds;
    
    public BrxEomRefCodeDaoImpl(DataSource ds) {
        this.ds = ds;
    }
    
    @Override
    public List<BrxEomRefCodeEntity> getRefCodeList(String refType) throws SQLException {
        if (refType == null || refType.isEmpty())
            return null;
        
        String query = "SELECT * "
                     + "FROM brx_eom_ref_code "
                     + "WHERE ref_type = ? ";
        
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = ds.getConnection();
            ps = con.prepareStatement(query);
            
            ps.setString(1, refType);
            
            ResultSet rs = ps.executeQuery();
            
            List<BrxEomRefCodeEntity> list = new ArrayList<>();
            
            while (rs.next()) {
                BrxEomRefCodeEntity entity = new BrxEomRefCodeEntity();
                entity.setRefType(rs.getString("ref_type"));
                entity.setRefCode(rs.getString("ref_code"));
                entity.setRefDesc(rs.getString("ref_desc"));
                entity.setRemarks(rs.getString("remarks"));
                entity.setRefValue1(rs.getString("ref_value1"));
                entity.setRefValue2(rs.getString("ref_value2"));
                entity.setRefValue3(rs.getString("ref_value3"));
                entity.setRefValue4(rs.getString("ref_value4"));
                entity.setRefValue5(rs.getString("ref_value5"));
                entity.setRefValue6(rs.getString("ref_value6"));
                entity.setCreateDate(rs.getDate("create_date"));
                list.add(entity);
            }
            
            return list;
        } catch (SQLException e) {
            _logger.error(e.getMessage(), e);
            throw e;
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
    }
    
    @Override
    public List<BrxEomRefCodeEntity> find(BrxEomRefCodeEntity entity) throws SQLException {
        
        String query = "SELECT * "
                     + "FROM brx_eom_ref_code "
                     + "WHERE 1 = 1 ";
        
        if (entity.getRefType() != null && !entity.getRefType().isEmpty())
            query += "  and ref_type = NVL(? , ref_type) " ;
        
        if (entity.getRefCode() != null && !entity.getRefCode().isEmpty())
            query += "  and ref_code = NVL(? , ref_code) ";
        
        if (entity.getRefDesc() != null && !entity.getRefDesc().isEmpty())
            query += "  and ref_desc = NVL(? , ref_desc) ";
        
        if (entity.getRemarks() != null && !entity.getRemarks().isEmpty())
            query += "  and remarks = NVL(? , remarks) ";
        
        if (entity.getRefValue1() != null && !entity.getRefValue1().isEmpty())
            query += "  and ref_value1 = NVL(? , ref_value1) ";
        
        if (entity.getRefValue2() != null && !entity.getRefValue2().isEmpty())
            query += "  and ref_value2 = NVL(? , ref_value2) ";
        
        if (entity.getRefValue3() != null && !entity.getRefValue3().isEmpty())
            query += "  and ref_value3 = NVL(? , ref_value3) ";
        
        if (entity.getRefValue4() != null && !entity.getRefValue4().isEmpty())
            query += "  and ref_value4 = NVL(? , ref_value4) ";
        
        if (entity.getRefValue5() != null && !entity.getRefValue5().isEmpty())
            query += "  and ref_value5 = NVL(? , ref_value5) ";
        
        if (entity.getRefValue6() != null && !entity.getRefValue6().isEmpty())
            query += "  and ref_value6 = NVL(? , ref_value6) ";
        
        if (entity.getCreateDate() != null)
            query += "  and create_date = NVL(?, create_date) ";
        
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = ds.getConnection();
            ps = con.prepareStatement(query);
            
            int i = 1;
            
            if (entity.getRefType() != null && !entity.getRefType().isEmpty())
                ps.setString(i++, entity.getRefType());
            
            if (entity.getRefCode() != null && !entity.getRefCode().isEmpty())
                ps.setString(i++, entity.getRefCode());
            
            if (entity.getRefDesc() != null && !entity.getRefDesc().isEmpty())
                ps.setString(i++, entity.getRefDesc());
            
            if (entity.getRemarks() != null && !entity.getRemarks().isEmpty())
                ps.setString(i++, entity.getRemarks());
            
            if (entity.getRefValue1() != null && !entity.getRefValue1().isEmpty())
                ps.setString(i++, entity.getRefValue1());
            
            if (entity.getRefValue2() != null && !entity.getRefValue2().isEmpty())
                ps.setString(i++, entity.getRefValue2());
            
            if (entity.getRefValue3() != null && !entity.getRefValue3().isEmpty())
                ps.setString(i++, entity.getRefValue3());
            
            if (entity.getRefValue4() != null && !entity.getRefValue4().isEmpty())
                ps.setString(i++, entity.getRefValue4());
            
            if (entity.getRefValue5() != null && !entity.getRefValue5().isEmpty())
                ps.setString(i++, entity.getRefValue5());
            
            if (entity.getRefValue6() != null && !entity.getRefValue6().isEmpty())
                ps.setString(i++, entity.getRefValue6());
            
            if (entity.getCreateDate() != null)
                ps.setDate(i++, (Date) entity.getCreateDate());
            
            ResultSet rs = ps.executeQuery();
            
            List<BrxEomRefCodeEntity> list = new ArrayList<>();
            
            while (rs.next()) {
                BrxEomRefCodeEntity result = new BrxEomRefCodeEntity();
                result.setRefType(rs.getString("ref_type"));
                result.setRefCode(rs.getString("ref_code"));
                result.setRefDesc(rs.getString("ref_desc"));
                result.setRemarks(rs.getString("remarks"));
                result.setRefValue1(rs.getString("ref_value1"));
                result.setRefValue2(rs.getString("ref_value2"));
                result.setRefValue3(rs.getString("ref_value3"));
                result.setRefValue4(rs.getString("ref_value4"));
                result.setRefValue5(rs.getString("ref_value5"));
                result.setRefValue6(rs.getString("ref_value6"));
                result.setCreateDate(rs.getDate("create_date"));
                list.add(result);
            }
            
            return list;
            
        } catch (SQLException e) {
            _logger.error(e.getMessage(), e);
            throw e;
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
    }
    
}
