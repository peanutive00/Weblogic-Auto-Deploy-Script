package hk.com.hkbn.itbss.utils;

/**
 * @description: this is string util
 * @author: leon.cheung
 * @create: 22-03-2018
 **/
public class StringUtils {

  private static String MSG_1="1";
  private static String MSG_0="0";
  public static String compareServiceType(String str) {
    if (MSG_1.equals(str) || MSG_0.equals(str)) {
      return str;
    } else{
      return null;
    }
  }
}
