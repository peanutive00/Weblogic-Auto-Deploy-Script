package hk.com.hkbn.itbss.constants;

/**
 * @description: this is class of response type
 * @author: leon.cheung
 * @create: 23-03-2018
 **/
public class ResponseType {

  public static final String SUCCESS = "success";
  public static final String ERROR = "error";
  public static final String FAIL = "fail";

}
