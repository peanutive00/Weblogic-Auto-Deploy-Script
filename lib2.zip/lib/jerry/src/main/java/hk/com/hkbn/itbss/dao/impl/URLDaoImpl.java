/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.URLDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor01
 */
public class URLDaoImpl implements URLDao {
    
    private final Logger _logger = LoggerFactory.getLogger(URLDaoImpl.class);
    private final DataSource ds;

    public URLDaoImpl(DataSource ds) {
        this.ds = ds;
    }
    
    @Override
    public String getWebServiceURL(String refType, String refCode) throws SQLException {
        if (refType == null || refType.isEmpty() ||
                refCode == null || refCode.isEmpty())
            return null;
        
        String query = "SELECT ref_value1 "
                     + "FROM brx_eom_ref_code "
                     + "WHERE ref_type = NVL(?, ref_type) "
                     + "  AND ref_code = NVL(?, ref_code) ";
        
        Connection connection = null;
        PreparedStatement statement = null;
        
        try {
            
            connection = ds.getConnection();
            statement = connection.prepareStatement(query);

            statement.setString(1, refType);
            statement.setString(2, refCode);
            
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()) {
                return rs.getString("ref_value1");
            }
            
        } catch(SQLException e) {
            _logger.error(e.getMessage(), e);
            throw e;
        }
        
        return null;
    }
    
}
