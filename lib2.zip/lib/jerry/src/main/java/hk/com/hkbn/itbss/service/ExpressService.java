package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.CreateOrder2Entity;
import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import java.sql.SQLException;
import javax.ejb.Local;

/**
 * @description:
 * @author: leon.cheung
 * @create: 12-04-2018
 **/
@Local
public interface ExpressService {
    
    public String createOrder(CreateOrder2Entity createOrder2Entity) throws SQLException;
    
}
