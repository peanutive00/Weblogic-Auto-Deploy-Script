/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import java.util.List;

/**
 * @author itbssvendor02
 */

/**
 * @Description: this is entity for plan filter response
 * @Author: leon.cheung
 * @Date: 3/20/2018
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "resultCode",
    "errorCode",
    "messageEnglish",
    "messageChinese",
    "imeiList"
})
public class EsMobileResponse {

  private String status;
  private String resultCode;
  private String errorCode;
  private String messageEnglish;
  private String messageChinese;
  private List<EquipmentEntity> imeiList;

  @JsonProperty("status")
  public String getStatus() {
    return status;
  }

  @JsonProperty("status")
  public void setStatus(String status) {
    this.status = status;
  }

  @JsonProperty("resultCode")
  public String getResultCode() {
    return resultCode;
  }
  @JsonProperty("resultCode")
  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  @JsonProperty("errorCode")
  public String getErrorCode() {
    return errorCode;
  }
  @JsonProperty("errorCode")
  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  @JsonProperty("messageEnglish")
  public String getMessageEnglish() {
    return messageEnglish;
  }
  @JsonProperty("messageEnglish")
  public void setMessageEnglish(String messageEnglish) {
    this.messageEnglish = messageEnglish;
  }

  @JsonProperty("messageChinese")
  public String getMessageChinese() {
    return messageChinese;
  }
  @JsonProperty("messageChinese")
  public void setMessageChinese(String messageChinese) {
    this.messageChinese = messageChinese;
  }

  @JsonProperty("imeiList")
  public List<EquipmentEntity> getImeiList() {
    return imeiList;
  }
  @JsonProperty("imeiList")
  public void setImeiList(List<EquipmentEntity> imeiList) {
    this.imeiList = imeiList;
  }

}
