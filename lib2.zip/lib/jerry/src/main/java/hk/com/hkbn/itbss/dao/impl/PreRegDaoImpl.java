/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.PreRegDao;
import hk.com.hkbn.itbss.entity.PreRegEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

/**
 *
 * @author itbssvendor01
 */
public class PreRegDaoImpl implements PreRegDao {

    private final DataSource ds;
    
    public PreRegDaoImpl(DataSource ds) {
        this.ds = ds;
    }
    
    @Override
    public PreRegEntity getPreRegInfo(String preRegCode) throws SQLException {
        String query = "SELECT * "
                     + "FROM bn_pre_reg "
                     + "WHERE pre_reg_code = ? ";
        
        Connection con = null;
        PreparedStatement ps = null;
        try {
            
            con = ds.getConnection();
            ps = con.prepareStatement(query);
            
            ps.setString(1, preRegCode);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                PreRegEntity entity = new PreRegEntity();
                entity.setPreRegCode(rs.getString("pre_reg_code"));
                entity.setSurname(rs.getString("surname"));
                entity.setGivenName(rs.getString("given_name"));
                entity.setStatus(rs.getString("status"));
                return entity;
            }
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
        
        return null;
    }
    
}
