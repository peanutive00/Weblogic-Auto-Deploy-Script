package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.constants.CommonConstants;
import hk.com.hkbn.itbss.dao.ExpressDao;
import hk.com.hkbn.itbss.dao.impl.ExpressDaoImpl;
import hk.com.hkbn.itbss.entity.CreateOrder2Entity;
import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import hk.com.hkbn.itbss.service.ExpressService;
import java.sql.SQLException;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @description:
 * @author: leon.cheung
 * @create: 12-04-2018
 **/
@Stateless
@LocalBean
public class ExpressServiceImpl implements ExpressService {

    private final Logger _logger = LoggerFactory.getLogger(ExpressServiceImpl.class);
    @Resource
    private EJBContext ctx;

    @Resource(name = "jdbc.hkbn")
    private DataSource ds;
    
    private ExpressDao dao;

    public ExpressServiceImpl() {

    }

    public ExpressServiceImpl(ExpressDao dao) {
        this.dao = dao;
    }

    @PostConstruct
    private void init() {
        this.dao = new ExpressDaoImpl(ds);
    }

    @Override
    public String createOrder(CreateOrder2Entity createOrder2Entity) throws SQLException {
        return dao.createOrder(createOrder2Entity);
    }

}
