/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

import java.io.InputStream;

/**
 *
 * @author itbssvendor02
 */

public class Picture {

    private InputStream content;
    private String contentType;
    
    public Picture() {
        this.contentType = "image/png";
    }

    public InputStream getContent() {
        return content;
    }

    public void setContent(InputStream content) {
        this.content = content;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
    
}
