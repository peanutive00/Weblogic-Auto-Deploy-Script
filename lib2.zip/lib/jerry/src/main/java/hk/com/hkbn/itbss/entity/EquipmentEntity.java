package hk.com.hkbn.itbss.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.List;

/**
 * @description:
 * @author: leon.cheung
 * @create: 11-04-2018
 **/
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "pps",
        "redemp_date",
        "redemp_flag",
        "imei",
        "itemId",
        "partNo",
        "serialNo",
        "descChi",
        "descEng",
        "cusStatus",
        "mobileStatus",
        "mobileLineNo",
        "giftDesc",
        "giftDescChi",
        "company"
})
public class EquipmentEntity extends EOEntity {

    @JsonProperty("pps")
    private String pps;
        
    @JsonProperty("redemp_date")
    private String redempDate;
        
    @JsonProperty("redemp_flag")
    private String redempFlag;
        
    @JsonProperty("imei")
    private String imei;
        
    @JsonProperty("itemId")
    private String itemId;
        
    @JsonProperty("partNo")
    private String partNo;
        
    @JsonProperty("serialNo")
    private String serialNo;
        
    @JsonProperty("descChi")
    private String descChi;
        
    @JsonProperty("descEng")
    private String descEng;
        
    @JsonProperty("cusStatus")
    private String cusStatus;
        
    @JsonProperty("mobileStatus")
    private String mobileStatus;
        
    @JsonProperty("mobileLineNo")
    private String mobileLineNo;
        
    @JsonProperty("giftDesc")
    private String giftDesc;
        
    @JsonProperty("giftDescChi")
    private String giftDescChi;
        
    //ES Only
    @JsonProperty("company")
    private String company;
        
    @JsonProperty("sim")
    private String sim;
        
    @JsonProperty("mobileLineNoCode")
    private String mobileLineNoCode;

    
    @JsonIgnore
    private boolean selected = false;

    public String getDescChi() {
        return descChi;
    }

    public void setDescChi(String descChi) {
        this.descChi = descChi;
    }

    public String getDescEng() {
        return descEng;
    }

    public void setDescEng(String descEng) {
        this.descEng = descEng;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getPartNo() {
        return partNo;
    }

    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getPps() {
        return pps;
    }

    public void setPps(String pps) {
        this.pps = pps;
    }

    public String getRedempDate() {
        return redempDate;
    }

    public void setRedempDate(String redempDate) {
        this.redempDate = redempDate;
    }

    public String getRedempFlag() {
        return redempFlag;
    }

    public void setRedempFlag(String redempFlag) {
        this.redempFlag = redempFlag;
    }

    public String getCusStatus() {
        return cusStatus;
    }

    public void setCusStatus(String cusStatus) {
        this.cusStatus = cusStatus;
    }

    public String getMobileStatus() {
        return mobileStatus;
    }

    public void setMobileStatus(String mobileStatus) {
        this.mobileStatus = mobileStatus;
    }

    public String getMobileLineNo() {
        return mobileLineNo;
    }

    public void setMobileLineNo(String mobileLineNo) {
        this.mobileLineNo = mobileLineNo;
    }

    public String getGiftDesc() {
        return giftDesc;
    }

    public void setGiftDesc(String giftDesc) {
        this.giftDesc = giftDesc;
    }

    public String getGiftDescChi() {
        return giftDescChi;
    }


    public void setGiftDescChi(String giftDescChi) {
        this.giftDescChi = giftDescChi;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
    
    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getSim() {
        return sim;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }

    public String getMobileLineNoCode() {
        return mobileLineNoCode;
    }

    public void setMobileLineNoCode(String mobileLineNoCode) {
        this.mobileLineNoCode = mobileLineNoCode;
    }
    
    @Override
    public String toString() {
        String str = "pps = " + pps
                   + ",redempDate = " + redempDate
                   + ",redempFlag = " + redempFlag
                   + ",imei = " + imei
                   + ",itemId = " + itemId
                   + ",partNo = " + partNo
                   + ",serialNo = " + serialNo
                   + ",descChi = " + descChi
                   + ",descEng = " + descEng
                   + ",cusStatus = " + cusStatus
                   + ",mobileStatus = " + mobileStatus
                   + ",mobileLineNo = " + mobileLineNo
                   + ",giftDesc = " + giftDesc
                   + ",giftDescChi = " + giftDescChi
                   + ",company = " + company
                   + ",sim = " + sim
                   + ",mobileLineNoCode = " + mobileLineNoCode;

        return str;
    }
}
