package hk.com.hkbn.itbss.entity;

public class ReplaceUpdateEntity {

  private String platform;
  private String pps;
  private String oldImei;
  private String itemId;
  private String newImei;
  private String shopNo;
  private String salesName;
  private String desc;
  private String chargeOption;

  public String getPlatform() {
    return platform;
  }

  public void setPlatform(String platform) {
    this.platform = platform;
  }

  public String getPps() {
    return pps;
  }

  public void setPps(String pps) {
    this.pps = pps;
  }

  public String getOldImei() {
    return oldImei;
  }

  public void setOldImei(String oldImei) {
    this.oldImei = oldImei;
  }

  public String getNewImei() {
    return newImei;
  }

  public void setNewImei(String newImei) {
    this.newImei = newImei;
  }

  public String getItemId() {
    return itemId;
  }

  public void setItemId(String itemId) {
    this.itemId = itemId;
  }

  public String getShopNo() {
    return shopNo;
  }

  public void setShopNo(String shopNo) {
    this.shopNo = shopNo;
  }

  public String getSalesName() {
    return salesName;
  }

  public void setSalesName(String salesName) {
    this.salesName = salesName;
  }

  public String getDesc() {
    return desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public String getChargeOption() {
    return chargeOption;
  }

  public void setChargeOption(String chargeOption) {
    this.chargeOption = chargeOption;
  }
}
