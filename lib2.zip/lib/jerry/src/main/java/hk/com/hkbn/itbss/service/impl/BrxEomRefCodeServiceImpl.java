/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.dao.BrxEomRefCodeDao;
import hk.com.hkbn.itbss.dao.impl.BrxEomRefCodeDaoImpl;
import hk.com.hkbn.itbss.entity.BrxEomRefCodeEntity;
import hk.com.hkbn.itbss.service.BrxEomRefCodeService;
import java.sql.SQLException;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;

/**
 *
 * @author itbssvendor01
 */
@Stateless
@LocalBean 
public class BrxEomRefCodeServiceImpl implements BrxEomRefCodeService {
    
    private org.slf4j.Logger _logger = org.slf4j.LoggerFactory.getLogger(BrxEomRefCodeService.class);
    
    @Resource(name = "jdbc.hkbn_omtest")
    private DataSource ds;
    
    private BrxEomRefCodeDao dao;
    
    public BrxEomRefCodeServiceImpl() {
    }
    
    public BrxEomRefCodeServiceImpl(BrxEomRefCodeDao dao) {
        this.dao = dao;
    }
    
    @PostConstruct
    private void init() {
        this.dao = new BrxEomRefCodeDaoImpl(ds);
    }
    
    @Override
    public List<BrxEomRefCodeEntity> getRefCodeList(String refType) throws SQLException {
        return dao.getRefCodeList(refType);
    }

    @Override
    public List<BrxEomRefCodeEntity> findAll(BrxEomRefCodeEntity entity) throws SQLException {
        return dao.find(entity);
    }
}
