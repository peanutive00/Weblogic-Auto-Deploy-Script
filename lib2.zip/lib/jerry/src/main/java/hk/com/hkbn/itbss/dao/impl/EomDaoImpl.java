/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.EomDao;
import hk.com.hkbn.itbss.entity.EomDetailEntity;
import hk.com.hkbn.itbss.entity.EomMasterEntity;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author itbssvendor01
 */
public class EomDaoImpl implements EomDao {
    
    private final DataSource ds;

    public EomDaoImpl(DataSource ds) {
        this.ds = ds;
    }
    
    private class Output {
        Integer code;
        String status;
        String message;
    }
    
    @Override
    public String createEom(EomMasterEntity master, EomDetailEntity detail, List<EomDetailEntity> subItemList) throws SQLException {
        Connection connection = ds.getConnection();
        connection.setAutoCommit(false);
        String message;
        
        Output masterOutput = this.createEomMaster(connection, master);
        message = masterOutput.message;
        
        if (masterOutput.status != null && masterOutput.status.equals("1")) {
            detail.setEomCode(masterOutput.code);
            Output detailOutput = this.createEomDetail(connection, detail);
            message = detailOutput.message;
            
            if (detailOutput.status != null && detailOutput.status.equals("1")) {
                
                if (subItemList != null && subItemList.size() > 0) {
                    for (EomDetailEntity subItem: subItemList) {
                        subItem.setEomCode(masterOutput.code);
                        subItem.setMasterEomDetailCode(detailOutput.code);
                        Output subItemOutput = this.createEomDetail(connection, subItem);
                        message = subItemOutput.message;
                        
                        if (subItemOutput.status == null || !subItemOutput.status.equals("1")) {
                            connection.rollback();
                            connection.close();
                            return message;
                        } else {
                            // Continue for-loop
                        }
                    }
                }
                
                connection.commit();
                
            } else {
                connection.rollback();
            }
            
        } else {
            connection.rollback();
        }
        
        connection.close();
        
        return message;
    }
    
    private Output createEomMaster(Connection connection, EomMasterEntity master) throws SQLException {
        String proc = "{CALL pkg_brx_eom.p_cre_eom_master(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
        
        CallableStatement statement = null;
        
        try {

            statement = connection.prepareCall(proc);
            
            if (master.getEomCode() == null)
                statement.setNull(1, Types.INTEGER);
            else
                statement.setInt(1, master.getEomCode());
            
            if (master.getEomChannel1() == null)
                statement.setNull(2, Types.VARCHAR);
            else
                statement.setString(2, master.getEomChannel1());
            
            if (master.getEomChannel2() == null)
                statement.setNull(3, Types.VARCHAR);
            else
                statement.setString(3, master.getEomChannel2());
            
            if (master.getEomChannelRefNo() == null)
                statement.setNull(4, Types.VARCHAR);
            else
                statement.setString(4, master.getEomChannelRefNo());
            
            if (master.getEomType() == null)
                statement.setNull(5, Types.VARCHAR);
            else
                statement.setString(5, master.getEomType());
            
            if (master.getRemark() == null)
                statement.setNull(6, Types.VARCHAR);
            else
                statement.setString(6, master.getRemark());
            
            if (master.getShopNo() == null)
                statement.setNull(7, Types.VARCHAR);
            else
                statement.setString(7, master.getShopNo());
            
            if (master.getStatus() == null)
                statement.setNull(8, Types.VARCHAR);
            else
                statement.setString(8, master.getStatus());
            
            if (master.getUserId() == null)
                statement.setNull(9, Types.VARCHAR);
            else
                statement.setString(9, master.getUserId());
            
            statement.registerOutParameter(10, Types.NUMERIC);
            statement.registerOutParameter(11, Types.VARCHAR);
            statement.registerOutParameter(12, Types.VARCHAR);
            
            statement.execute();
            
            Output output = new Output();
            output.code = statement.getInt(10);
            output.status = statement.getString(11);
            output.message = statement.getString(12);
            
            return output;
            
        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
        }
    }
    
    private Output createEomDetail(Connection connection, EomDetailEntity detail) throws SQLException {
        String proc = "{CALL pkg_brx_eom.p_cre_eom_detail(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
        
        CallableStatement statement = null;
        
        try {

            statement = connection.prepareCall(proc);
            
            if (detail.getEomDetailCode() == null)
                statement.setNull(1, Types.INTEGER);
            else
                statement.setInt(1, detail.getEomDetailCode());
            
            if (detail.getEomCode() == null)
                statement.setNull(2, Types.INTEGER);
            else
                statement.setInt(2, detail.getEomCode());
            
            if (detail.getEoType1() == null)
                statement.setNull(3, Types.VARCHAR);
            else
                statement.setString(3, detail.getEoType1());
            
            if (detail.getEoCode1() == null)
                statement.setNull(4, Types.VARCHAR);
            else
                statement.setString(4, detail.getEoCode1());
            
            if (detail.getSerialNo1() == null)
                statement.setNull(5, Types.VARCHAR);
            else
                statement.setString(5, detail.getSerialNo1());
            
            if (detail.getEoType2() == null)
                statement.setNull(6, Types.VARCHAR);
            else
                statement.setString(6, detail.getEoType2());
            
            if (detail.getEoCode2() == null)
                statement.setNull(7, Types.VARCHAR);
            else
                statement.setString(7, detail.getEoCode2());
            
            if (detail.getSerialNo2() == null)
                statement.setNull(8, Types.VARCHAR);
            else
                statement.setString(8, detail.getSerialNo2());
            
            if (detail.getMasterEomDetailCode() == null)
                statement.setNull(9, Types.INTEGER);
            else
                statement.setInt(9, detail.getMasterEomDetailCode());
            
            if (detail.getChargeAmount() == null)
                statement.setNull(10, Types.DOUBLE);
            else
                statement.setDouble(10, detail.getChargeAmount());
            
            if (detail.getChargeFlag() == null)
                statement.setNull(11, Types.VARCHAR);
            else
                statement.setString(11, detail.getChargeFlag());
            
            if (detail.getUserId() == null)
                statement.setNull(12, Types.VARCHAR);
            else
                statement.setString(12, detail.getUserId());
            
            statement.registerOutParameter(13, Types.NUMERIC);
            statement.registerOutParameter(14, Types.VARCHAR);
            statement.registerOutParameter(15, Types.VARCHAR);
            
            statement.execute();
            
            Output output = new Output();
            output.code = statement.getInt(13);
            output.status = statement.getString(14);
            output.message = statement.getString(15);
            
            return output;
            
        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
        }
    }
}
