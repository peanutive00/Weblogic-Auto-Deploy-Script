package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.dao.BnShopStaffDao;
import hk.com.hkbn.itbss.dao.impl.BnShopStaffDaoImpl;
import hk.com.hkbn.itbss.service.BnShopStaffService;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor02
 */

@Stateless
@LocalBean
public class BnShopStaffServiceImpl implements BnShopStaffService {
    
    private final Logger _logger = LoggerFactory.getLogger(BnShopStaffServiceImpl.class);
    
    @Resource
    private EJBContext ctx;
    @Resource(name = "jdbc.hkbn")
    private DataSource ds;
    
    private BnShopStaffDao dao;

    public BnShopStaffServiceImpl() {
        
    }

    public BnShopStaffServiceImpl(BnShopStaffDao dao) {
        this.dao = dao;
    }
    
    @PostConstruct
    public void init(){
        this.dao = new BnShopStaffDaoImpl(ds);
    }

    @Override
    public String getStaffShopNo(String loginId) {
        try{
            return dao.findStaffShopNo(loginId);
        }catch(Exception ex){
            _logger.error(ex.getMessage());
            return "";
        }
    }
    
}
