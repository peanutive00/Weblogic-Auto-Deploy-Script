import React, { Component } from 'react';

class App extends Component {

  constructor() {
    super();
    console.log("hello world");
  }

  render() {
    return (
      <div>
        <h1>Hello world</h1>
        <button onClick={this.handleClick}>Click</button>
      </div>
    );
  }

  handleClick() {
    console.log("It works!!!"); 
  }

}

export default App;
