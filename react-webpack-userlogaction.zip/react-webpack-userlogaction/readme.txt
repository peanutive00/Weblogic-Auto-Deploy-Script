https://mherman.org/blog/dockerizing-a-react-app/
https://medium.com/curofy-engineering/a-guide-to-inject-variable-into-your-code-using-webpack-36c49fcc1dcd
https://medium.com/dailyjs/inserting-variables-into-html-and-javascript-with-webpack-80f33625edc6