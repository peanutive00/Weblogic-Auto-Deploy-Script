/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.apple.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 *
 * @author itbssvendor02
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PurchaseAppleCarePlusResponse {
    
    @JsonProperty("PocDtl")
    private PocDtl pocDtl;
    
    @JsonProperty("Status")
    private String status;
    
    @JsonProperty("Message")
    private String message;

    @JsonProperty("PocDtl")
    public PocDtl getPocDtl() {
        return pocDtl;
    }

    @JsonProperty("PocDtl")
    public void setPocDtl(PocDtl pocDtl) {
        this.pocDtl = pocDtl;
    }
    
    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("Message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("Message")
    public void setMessage(String message) {
        this.message = message;
    }
    
}
