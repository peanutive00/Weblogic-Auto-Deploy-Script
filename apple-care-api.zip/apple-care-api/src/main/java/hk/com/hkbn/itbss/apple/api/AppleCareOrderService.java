package hk.com.hkbn.itbss.apple.api;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import hk.com.hkbn.itbss.apple.dao.AppleCareOrderDao;
import hk.com.hkbn.itbss.apple.constant.CommonConstants;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelResponse;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusResponse;

import java.io.IOException;
import java.sql.SQLException;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2018-05-10T10:50:01.867Z")
public interface AppleCareOrderService {
	PurchaseAppleCarePlusCancelResponse cancelOrder(PurchaseAppleCarePlusCancelRequest request) throws IOException, SQLException;    	
    PurchaseAppleCarePlusResponse createOrder(PurchaseAppleCarePlusRequest request) throws IOException, SQLException;
}

