package hk.com.hkbn.itbss.apple.impl;


import hk.com.hkbn.itbss.apple.api.AppleCareOrderService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import hk.com.hkbn.itbss.apple.dao.AppleCareOrderDao;
import hk.com.hkbn.itbss.apple.constant.CommonConstants;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelResponse;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusResponse;

import java.io.IOException;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import javax.ws.rs.core.Context;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@LocalBean
@Stateless(name = "appleCareOrderServiceImpl", mappedName = "appleCareOrderServiceImpl")
public class AppleCareOrderServiceImpl implements AppleCareOrderService{


    @Resource(name = "jdbc.hkbn")
    private DataSource ds;
    
    @Context
    private HttpServletRequest httpServletRequest;
	
    private AppleCareOrderDao dao;
    
    @PostConstruct
    private void init() {
    	dao = new AppleCareOrderDao(ds);
    }
    
    
    private static final Logger LOG = LoggerFactory.getLogger(AppleCareOrderServiceImpl.class);

    private Client client;
    private WebResource webResourceCreateOrder;
    private WebResource webResourceCancelOrder;
    
    public AppleCareOrderServiceImpl() {
        this.client = Client.create();
        this.webResourceCreateOrder = client.resource(CommonConstants.PURCHASE_APPLE_CARE_PLUS_API_URL);
        this.webResourceCancelOrder = client.resource(CommonConstants.CANCEL_PURCHASE_APPLE_CARE_PLUS_API_URL);
        this.client.setConnectTimeout(30);
    }      

    @Override
    public PurchaseAppleCarePlusResponse createOrder(PurchaseAppleCarePlusRequest request) throws IOException, SQLException {
    	
        return null;
        
//    	try {
//            
//            String authStringEnc = new String( Base64.encodeBase64( (CommonConstants.API_USER_NAME + ":" + CommonConstants.API_PASSWORD).getBytes() ) );
//            
//            ClientResponse response = (ClientResponse) webResourceCreateOrder.type("application/json")
//                                                                  .header("Authorization", "Basic " + authStringEnc)
//                                                                  .post(ClientResponse.class, new ObjectMapper().writeValueAsString(request));            
//            
//            String resString = (String)response.getEntity(String.class);
//            PurchaseAppleCarePlusResponse result = new ObjectMapper().readValue(resString, PurchaseAppleCarePlusResponse.class);
//            dao.createOrder(request, result);
//            response.close();
//            
//            return result;
//            
//        } catch (Exception ex) {
//        	LoggerFactory.getLogger(AppleCareOrderServiceImpl.class);
//            ex.printStackTrace();
//            return null;
//        }
    }

    @Override
    public PurchaseAppleCarePlusCancelResponse cancelOrder(PurchaseAppleCarePlusCancelRequest request) throws IOException, SQLException {
    	
        return null;
        
//    	try {
//            
//            String authStringEnc = new String( Base64.encodeBase64( (CommonConstants.API_USER_NAME + ":" + CommonConstants.API_PASSWORD).getBytes() ) );
//            
//            ClientResponse response = (ClientResponse) webResourceCancelOrder.type("application/json")
//                                                                  .header("Authorization", "Basic " + authStringEnc)
//                                                                  .post(ClientResponse.class, new ObjectMapper().writeValueAsString(request));            
//            
//            String resString = (String)response.getEntity(String.class);
//            PurchaseAppleCarePlusCancelResponse result = new ObjectMapper().readValue(resString, PurchaseAppleCarePlusCancelResponse.class);
//            dao.cancelOrder(request, result);
//            response.close();
//            
//            return result;
//            
//        } catch (Exception ex) {
//        	LoggerFactory.getLogger(AppleCareOrderServiceImpl.class);
//            ex.printStackTrace();
//            return null;
//        }
    }   
}
