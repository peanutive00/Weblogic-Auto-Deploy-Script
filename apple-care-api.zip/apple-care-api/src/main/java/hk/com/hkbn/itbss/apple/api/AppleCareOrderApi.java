package hk.com.hkbn.itbss.apple.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.ApiParam;
//import hk.com.hkbn.itbss.apple.impl.AppleCareOrderServiceImpl;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelResponse;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusResponse;

import java.io.IOException;
import java.sql.SQLException;

import javax.ws.rs.*;

//import com.fasterxml.jackson.databind.ObjectMapper;
import javax.ws.rs.core.MediaType;

@Path("/order")
//@io.swagger.annotations.Api(description = "the payment API")
//@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2018-05-10T10:50:01.867Z")
public class AppleCareOrderApi {

//    @EJB
//    private AppleCareOrderServiceImpl appleCareOrderServiceImpl;
    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    //@io.swagger.annotations.ApiOperation(value = "Create a real-time transaction with payment token", notes = "Create a real-time transaction with payment token", response = PurchaseAppleCarePlusRequest.class)
//    @io.swagger.annotations.ApiResponses(value = {
//        
//        @io.swagger.annotations.ApiResponse(code = 400, message = "invalid input, object invalid", response = Void.class)
//        ,
//        
//        @io.swagger.annotations.ApiResponse(code = 401, message = "the login ID doesn’t have right to create payment token", response = Void.class)
//        ,
//        
//        @io.swagger.annotations.ApiResponse(code = 500, message = "internal server error", response = Void.class)})
    public PurchaseAppleCarePlusResponse createOrder(PurchaseAppleCarePlusRequest request) {

        try {

            System.out.println(request);
            
            System.out.println(request != null);

            

            return null;

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            return null;
        }

        //return appleCareOrderServiceImpl.createOrder(request);
    }

    @POST
    @Path("/cancel")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    @io.swagger.annotations.ApiOperation(value = "Create a real-time transaction with payment token", notes = "Create a real-time transaction with payment token", response = PurchaseAppleCarePlusRequest.class)
    @io.swagger.annotations.ApiResponses(value = {
        @io.swagger.annotations.ApiResponse(code = 400, message = "invalid input, object invalid", response = Void.class)
        ,
        
        @io.swagger.annotations.ApiResponse(code = 401, message = "the login ID doesn’t have right to create payment token", response = Void.class)
        ,
        
        @io.swagger.annotations.ApiResponse(code = 500, message = "internal server error", response = Void.class)})
    public PurchaseAppleCarePlusCancelResponse cancelOrder(@ApiParam(value = "Payment Item") PurchaseAppleCarePlusCancelRequest request)
            throws NotFoundException, IOException, SQLException {
        return null;
        //return appleCareOrderServiceImpl.cancelOrder(request);
    }

}
