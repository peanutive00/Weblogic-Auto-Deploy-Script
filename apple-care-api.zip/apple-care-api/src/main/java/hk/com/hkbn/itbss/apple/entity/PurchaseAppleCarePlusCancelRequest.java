/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.apple.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 *
 * @author itbssvendor02
 */

@JsonPropertyOrder({
    "DeviceId",
    "PurchaseOrderNo",
    "CancelDate"
})

@JsonInclude(Include.ALWAYS)
public class PurchaseAppleCarePlusCancelRequest {

    @JsonProperty("DeviceId")
    private String deviceId;

    @JsonProperty("PurchaseOrderNo")
    private String purchaseOrderNo;

    @JsonProperty("CancelDate")
    private String cancelDate;

    @JsonProperty("DeviceId")
    public String getDeviceId() {
        return deviceId;
    }

    @JsonProperty("DeviceId")
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    @JsonProperty("PurchaseOrderNo")
    public String getPurchaseOrderNo() {
        return purchaseOrderNo;
    }

    @JsonProperty("PurchaseOrderNo")
    public void setPurchaseOrderNo(String purchaseOrderNo) {
        this.purchaseOrderNo = purchaseOrderNo;
    }

    @JsonProperty("CancelDate")
    public String getCancelDate() {
        return cancelDate;
    }

    @JsonProperty("CancelDate")
    public void setCancelDate(String cancelDate) {
        this.cancelDate = cancelDate;
    }

}
