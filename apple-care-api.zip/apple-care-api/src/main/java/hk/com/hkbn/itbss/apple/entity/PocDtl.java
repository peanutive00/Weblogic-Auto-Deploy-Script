/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.apple.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 * @author itbssvendor02
 */
public class PocDtl {
    
    @JsonProperty("PartType")
    private String partType;
    
    @JsonProperty("AppleCareSalesDate")
    private String appleCareSalesDate;
    
    @JsonProperty("AgreementNo")
    private String agreementNo;
    
    private String deviceId;
    
    @JsonProperty("ProductDescription")
    private String productDescription;
    
    @JsonProperty("CoverageDurStmt")
    private String coverageDurStmt;
    
    @JsonProperty("ProductStmt")
    private String productStatement;
    
    @JsonProperty("TermConUrl")
    private String termConUrl;

    @JsonProperty("PartType")
    public String getPartType() {
        return partType;
    }

    @JsonProperty("PartType")
    public void setPartType(String partType) {
        this.partType = partType;
    }

    @JsonProperty("AppleCareSalesDate")
    public String getAppleCareSalesDate() {
        return appleCareSalesDate;
    }

    @JsonProperty("AppleCareSalesDate")
    public void setAppleCareSalesDate(String appleCareSalesDate) {
        this.appleCareSalesDate = appleCareSalesDate;
    }

    @JsonProperty("AgreementNo")
    public String getAgreementNo() {
        return agreementNo;
    }

    @JsonProperty("AgreementNo")
    public void setAgreementNo(String agreementNo) {
        this.agreementNo = agreementNo;
    }
    
    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    @JsonProperty("ProductDescription")
    public String getProductDescription() {
        return productDescription;
    }

    @JsonProperty("ProductDescription")
    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    @JsonProperty("CoverageDurStmt")
    public String getCoverageDurStmt() {
        return coverageDurStmt;
    }

    @JsonProperty("CoverageDurStmt")
    public void setCoverageDurStmt(String coverageDurStmt) {
        this.coverageDurStmt = coverageDurStmt;
    }

    @JsonProperty("ProductStmt")
    public String getProductStatement() {
        return productStatement;
    }

    @JsonProperty("ProductStmt")
    public void setProductStatement(String productStatement) {
        this.productStatement = productStatement;
    }

    @JsonProperty("TermConUrl")
    public String getTermConUrl() {
        return termConUrl;
    }

    @JsonProperty("TermConUrl")
    public void setTermConUrl(String termConUrl) {
        this.termConUrl = termConUrl;
    }
    
}
