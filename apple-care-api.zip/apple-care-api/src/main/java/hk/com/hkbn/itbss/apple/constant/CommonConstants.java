/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.apple.constant;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author itbssvendor02
 */

public class CommonConstants {
    
    /**
     * DMS UAT API url
     */
    public static final String DMS_CREATE_DOCUMENT_API_URL = "https://dmsuat.hkbn.com.hk/paradm-ws/api/dms/document/createDocument";
    
    /**
     * AC+ UAT API url
     */
    public static final String PURCHASE_APPLE_CARE_PLUS_API_URL = "http://mvno-internal-qa.hkbn.com.hk/AppleCarePlus/api/AppleCare/CreateOrder";
    public static final String CANCEL_PURCHASE_APPLE_CARE_PLUS_API_URL = "http://mvno-internal-qa.hkbn.com.hk/AppleCarePlus/api/AppleCare/CancelOrder";
    public static final String API_USER_NAME = "itbsshk";
    public static final String API_PASSWORD = "hkbn1310!";

    /**
     * create order time frame
     */
    static final Date _080000 = parseDate("08:00:00");
    static final Date _100000 = parseDate("10:00:00");
    static final Date _120000 = parseDate("12:00:00");
    static final Date _140000 = parseDate("14:00:00");
    static final Date _160000 = parseDate("16:00:00");
    static final Date _180000 = parseDate("18:00:00");
    static final Date _200000 = parseDate("20:00:00");
    static final Date _220000 = parseDate("22:00:00");
    static final Date _235900 = parseDate("23:59:59");
    
    static Date parseDate(String time){
        try{
            return new SimpleDateFormat("HH:mm:ss").parse(time);
        }catch(Exception ex){
            return new Date(0);
        }
    }
    
    public static String getTimeFrame(Date d){
        
        String timeFrame = "";
        
        if(d.after(_080000) && d.before(_100000)){
            timeFrame = "08:00-10:00";
        }else if(d.after(_100000) && d.before(_120000)){
            timeFrame = "10:00-12:00";
        }else if(d.after(_120000) && d.before(_140000)){
            timeFrame = "12:00-14:00";
        }else if(d.after(_140000) && d.before(_160000)){
            timeFrame = "14:00-16:00";
        }else if(d.after(_160000) && d.before(_180000)){
            timeFrame = "16:00-18:00";
        }else if(d.after(_180000) && d.before(_200000)){
            timeFrame = "18:00-20:00";
        }else if(d.after(_200000) && d.before(_220000)){
            timeFrame = "20:00-22:00";
        }else if(d.after(_220000) && d.before(_235900)){
            timeFrame = "22:00-23:59";
        }
        
        return timeFrame;
        
    }
    
}
