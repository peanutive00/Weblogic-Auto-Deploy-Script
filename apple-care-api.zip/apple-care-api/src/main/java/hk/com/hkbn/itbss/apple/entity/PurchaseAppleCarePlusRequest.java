/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.apple.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 *
 * @author itbssvendor02
 */

@JsonPropertyOrder({
    "AppleCareSalesDate",
    "PocLanguage",
    "PocDeliveryPreference",
    "PurchaseOrderNo",
    "DeviceId",
    "SecSN",
    "DateOfPurchase",
    "VerifyMPN",
    "NSPart",
    "CustInfo"
})
@JsonInclude(Include.ALWAYS)
public class PurchaseAppleCarePlusRequest {
    
    @JsonProperty("AppleCareSalesDate")
    private String appleCareSalesDate;
    
    @JsonProperty("PocLanguage")
    private String pocLanguage;
    
    @JsonProperty("PocDeliveryPreference")
    private String pocDeliveryPreference;
    
    @JsonProperty("PurchaseOrderNo")
    private String purchaseOrderNo;
    
    @JsonProperty("DeviceId")
    private String deviceId;
    
    
    @JsonProperty("SecSN")
    private String secSN;
    
    @JsonProperty("DateOfPurchase")
    private String dateOfPurchase;
    
    
    @JsonProperty("VerifyMPN")
    private String verifyMPN;
    
    
    @JsonProperty("NSPart")
    private String nsPart;
    
    @JsonProperty("CustInfo")
    private CustInfo custInfo; 

    @JsonProperty("AppleCareSalesDate")
    public String getAppleCareSalesDate() {
        return appleCareSalesDate;
    }

    @JsonProperty("AppleCareSalesDate")
    public void setAppleCareSalesDate(String appleCareSalesDate) {
        this.appleCareSalesDate = appleCareSalesDate;
    }

    @JsonProperty("PocLanguage")
    public String getPocLanguage() {
        return pocLanguage;
    }

    @JsonProperty("PocLanguage")
    public void setPocLanguage(String pocLanguage) {
        this.pocLanguage = pocLanguage;
    }

    
    @JsonProperty("PocDeliveryPreference")
    public String getPocDeliveryPreference() {
        return pocDeliveryPreference;
    }

    @JsonProperty("PocDeliveryPreference")
    public void setPocDeliveryPreference(String pocDeliveryPreference) {
        this.pocDeliveryPreference = pocDeliveryPreference;
    }

    @JsonProperty("PurchaseOrderNo")
    public String getPurchaseOrderNo() {
        return purchaseOrderNo;
    }

    @JsonProperty("PurchaseOrderNo")
    public void setPurchaseOrderNo(String purchaseOrderNo) {
        this.purchaseOrderNo = purchaseOrderNo;
    }

    @JsonProperty("DeviceId")
    public String getDeviceId() {
        return deviceId;
    }

    @JsonProperty("DeviceId")
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    
    @JsonProperty("SecSN")
    public String getSecSN() {
        return secSN;
    }

    @JsonProperty("SecSN")
    public void setSecSN(String secSN) {
        this.secSN = secSN;
    }

    @JsonProperty("DateOfPurchase")
    public String getDateOfPurchase() {
        return dateOfPurchase;
    }

    @JsonProperty("DateOfPurchase")
    public void setDateOfPurchase(String dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    
    @JsonProperty("VerifyMPN")
    public String getVerifyMPN() {
        return verifyMPN;
    }

    @JsonProperty("VerifyMPN")
    public void setVerifyMPN(String verifyMPN) {
        this.verifyMPN = verifyMPN;
    }

    
    @JsonProperty("NSPart")
    public String getNsPart() {
        return nsPart;
    }

    @JsonProperty("NSPart")
    public void setNsPart(String nsPart) {
        this.nsPart = nsPart;
    }

    @JsonProperty("CustInfo")
    public CustInfo getCustInfo() {
        return custInfo;
    }

    @JsonProperty("CustInfo")
    public void setCustInfo(CustInfo custInfo) {
        this.custInfo = custInfo;
    }
    
}
