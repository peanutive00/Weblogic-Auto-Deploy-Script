package hk.com.hkbn.itbss.apple.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusCancelResponse;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusRequest;
import hk.com.hkbn.itbss.apple.entity.PurchaseAppleCarePlusResponse;

@Stateless
@LocalBean
public class AppleCareOrderDao{

	private static final Logger logger = LoggerFactory.getLogger(AppleCareOrderDao.class);
	
    private DataSource ds;
        
    public AppleCareOrderDao() {
    }
    
    public AppleCareOrderDao(DataSource dataSource) {
        this.ds = dataSource;
    }
    
    
    
    public void createOrder(PurchaseAppleCarePlusRequest request, PurchaseAppleCarePlusResponse response) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try{
			String sql = "INSERT INTO apple_ac_create_order (order_id, imei, doc_flag, lang, status, MESSAGE, agreement_no, part_type, apple_care_sales_date, product_description, coverage_dur_stmt, term_con_url, product_statment, create_date, staff_create, amend_date, staff_amend) "
					+ "VALUES (apple_ac_create_order_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, USER, null, null)";
			conn = ds.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, request.getDeviceId());
			ps.setString(2, "N");
			ps.setString(3, request.getPocLanguage());
			ps.setString(4, response.getStatus());
			ps.setString(5, response.getMessage());
			ps.setString(6, response.getPocDtl().getAgreementNo());
			ps.setString(7, response.getPocDtl().getPartType());
			ps.setString(8, response.getPocDtl().getAppleCareSalesDate());
			ps.setString(9, response.getPocDtl().getProductDescription());
			ps.setString(10, response.getPocDtl().getCoverageDurStmt());
			ps.setString(11, response.getPocDtl().getTermConUrl());
			ps.setString(12, response.getPocDtl().getProductStatement());
			
			ps.executeUpdate();
		}catch (Exception e) {
			throw e;
		} finally {
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
    }
    public void cancelOrder(PurchaseAppleCarePlusCancelRequest request, PurchaseAppleCarePlusCancelResponse response) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try{
			String sql = "INSERT INTO apple_ac_cancel_order (order_id, imei, doc_flag, status, MESSAGE, create_date, staff_create, amend_date, staff_amend) "
					+ "VALUES (?, ?, ?, ?, ?, sysdate, USER, null, null)";
			conn = ds.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, request.getPurchaseOrderNo());
			ps.setString(2, request.getDeviceId());
			ps.setString(3, "N");
			ps.setString(4, response.getStatus());
			ps.setString(5, response.getMessage());
			
			ps.executeUpdate();
		}catch (Exception e) {
			throw e;
		} finally {
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
    }
}
