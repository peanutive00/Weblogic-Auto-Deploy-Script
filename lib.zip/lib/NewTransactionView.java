/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.view.components;

import hk.com.hkbn.itbss.bo.EquipmentOfferBo;
import hk.com.hkbn.itbss.entity.BrxEomRefCodeEntity;
import hk.com.hkbn.itbss.entity.CustomerEntity;
import hk.com.hkbn.itbss.entity.EOEntity;
import hk.com.hkbn.itbss.entity.EomDetailEntity;
import hk.com.hkbn.itbss.entity.EomMasterEntity;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import hk.com.hkbn.itbss.entity.OfferEntity;
import hk.com.hkbn.itbss.entity.Picture;
import hk.com.hkbn.itbss.entity.PreRegEntity;
import hk.com.hkbn.itbss.entity.ReplacementCheckEntity;
import hk.com.hkbn.itbss.entity.SubItem;
import hk.com.hkbn.itbss.lib.view.CustomView;
import hk.com.hkbn.itbss.service.BnShopStaffService;
import hk.com.hkbn.itbss.service.EquipmentOfferService;
import hk.com.hkbn.itbss.service.PreRegService;
import hk.com.hkbn.itbss.service.BrxEomRefCodeService;
import hk.com.hkbn.itbss.service.CustomerService;
import hk.com.hkbn.itbss.service.EomService;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AjaxBehaviorEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor02
 */
@ManagedBean(name = "newTransactionView")
@ViewScoped
public class NewTransactionView extends CustomView {

    private static final Logger _logger = LoggerFactory.getLogger(NewTransactionView.class);

    //https://stackoverflow.com/questions/26749241/primefaces-datagrid-filter-by-inputtext
    private EquipmentOfferBo equipmentOfferBo = new EquipmentOfferBo();

    private String username;

    private String shopNo;

    @EJB
    private CustomerService customerService;

    @EJB
    private PreRegService preRegService;

    @EJB
    private EquipmentOfferService equipmentOfferService;

    @EJB
    private BrxEomRefCodeService brxEomRefCodeService;

    @EJB
    private BnShopStaffService bnShopStaffService;

    @EJB
    private EomService eomService;

    private List<BrxEomRefCodeEntity> channels;

    private List<BrxEomRefCodeEntity> factors;

    private List<BrxEomRefCodeEntity> eoms;

    private String channelType;

    private String factorType;

    private String factorValue;

    private Integer selectedEomIndex;

    private BrxEomRefCodeEntity selectedEom;

    private String eomType;

    private List<EquipmentEntity> equipList;

    private List<EOEntity> eoList;

    private EOEntity selectedEO;

    private String newDevice;

    private String chargeOption;

    private String remarks;

    private CustomerEntity customerEntity;

    private PreRegEntity preRegEntity;

    private ReplacementCheckEntity checkInfo;

    private EquipmentEntity selectedDevice;

    private EquipmentEntity checkNewDevice;

    private Picture picture;

    private DefaultStreamedContent pic;

    /**
     * GUI Control
     */
    private boolean showFactorType;

    private boolean isFound;

    /**
     * filter
     */
    private String serialNoFilter;

    @PostConstruct
    public void init() {
        try {
            
            this.channels = new ArrayList<>(this.brxEomRefCodeService.findAll(new BrxEomRefCodeEntity() {
                {
                    setRefType("EOM_CHANNEL_1");
                }
            }));

            this.factors = new ArrayList<>();

            this.eoms = new ArrayList<>();

            this.equipList = new ArrayList<>();

            this.eoList = new ArrayList<>();

            this.selectedEO = null;

            this.channelType = "";

            this.showFactorType = false;

            this.isFound = false;

            this.customerEntity = new CustomerEntity();

            this.preRegEntity = new PreRegEntity();

            this.checkInfo = new ReplacementCheckEntity();

            this.checkNewDevice = new EquipmentEntity();

            this.factorType = null;

            this.factorValue = null;

            this.selectedEomIndex = null;

            this.selectedEom = null;
            
            this.serialNoFilter = null;
            
            this.remarks = null;
            
        } catch (Exception ex) {
            _logger.error(ex.getMessage());
        }
    }

    public void executeSearch() {

        try {

            this.serialNoFilter = null;

            if (this.factorValue != null && !this.factorValue.isEmpty()) {

                if (this.channelType.equals("RES")) {
                    /**
                     * If channel type is RES.
                     */

                    if (this.factorType.equals("PPS")) {

//                        this.customerInfoEntity = new CustomerInfoEntity();
//
//                        //this.checkInfo = this.replacementService.checkInfo("RES", "711379070", "", ""); test
//                        
//                        this.checkInfo = this.resReplacementService.getRESEquipmentInfoByPps(this.factor);
//                        
//                        this.checkInfo = this.replacementService.checkInfo(this.channelType.toUpperCase(), this.factorValue, null, null);
//
//                        if (this.checkInfo.getEquipList() != null) {
//
//                            this.isFound = true;
//
//                            this.customerInfoEntity.setPps(this.checkInfo.getPps());
//                            this.customerInfoEntity.setCustomerName(this.checkInfo.getCusName());
//                            this.customerInfoEntity.setStatus(this.checkInfo.getCusStatus());
//
//                            
//                            if (!this.checkInfo.getCusStatus().equals("A") && 
//                                !this.checkInfo.getCusStatus().equals("S")) 
//                                showErrorMessage("Not allow to replacement, because account not active or suspense.");
//                            
//                            
//
//                            if (this.checkInfo.getEquipList() != null) {
//
//                                List<String> imeiList = new ArrayList<>();
//
//                                for (EquipmentEntity ei : this.checkInfo.getEquipList()) {
//                                    imeiList.add(ei.getImei());
//                                }
//
//                                ReplacementCheckEntity checkItemId = this.replacementService.checkItemId(imeiList);
//
//                                for (int i = 0; i < this.checkInfo.getEquipList().size(); i++) {
//                                    for (int y = 0; y < checkItemId.getEquipList().size(); y++) {
//                                        if (checkInfo.getEquipList().get(i).getImei() != null) {
//                                            if (checkInfo.getEquipList().get(i).getImei().equals(checkItemId.getEquipList().get(y).getImei())) {
//                                                checkInfo.getEquipList().get(i).setDescChi(checkItemId.getEquipList().get(y).getDescChi());
//                                                checkInfo.getEquipList().get(i).setDescEng(checkItemId.getEquipList().get(y).getDescEng());
//                                                checkInfo.getEquipList().get(i).setItemId(checkItemId.getEquipList().get(y).getItemId());
//                                                checkInfo.getEquipList().get(i).setPartNo(checkItemId.getEquipList().get(y).getPartNo());
//                                                checkInfo.getEquipList().get(i).setSerialNo(checkItemId.getEquipList().get(y).getSerialNo());
//                                            }
//                                        }
//                                    }
//                                }
//
//                            }
//
//                        } else {
//                            this.isFound = false;
//                        }
                        this.customerEntity = this.customerService.getCusInfo(this.factorValue);

                        this.eoList = this.equipmentOfferService.getResEoByPps(this.factorValue);

                        if (this.eoList != null) {

                            this.isFound = true;
                            showSuccessMessage("Success to retrieve eolist");

                            for (EOEntity eo : this.eoList) {
                                eo.setEoType("Equip");
                                eo.setChargeFee(1230.0);
                                eo.setSubItems(new ArrayList<SubItem>() {
                                    {
                                        add(new SubItem() {
                                            {
                                                setItemId("11");
                                                setDesc("ItemA");
                                                setChargeFee(Double.valueOf(124.0));
                                            }
                                        });
                                        add(new SubItem() {
                                            {
                                                setItemId("26");
                                                setDesc("ItemB");
                                                setChargeFee(147.0);
                                            }
                                        });
                                        add(new SubItem() {
                                            {
                                                setItemId("37");
                                                setDesc("GMS1SP&C Glocal Me Inside World Phone S1 - Screen Protector & Cover");
                                                setChargeFee(Double.valueOf(1282.0));
                                            }
                                        });
                                    }
                                });
                            }

                            for (int i = 0; i < eoList.size(); i++) {
                                if (eoList.get(i) != null) {
                                    if (i == 0) {
                                        eoList.get(i).setSerialNo("123");
                                    }
                                    if (i == 1) {
                                        eoList.get(i).setSerialNo("456");
                                    }
                                    if (i == 2) {
                                        eoList.get(i).setSerialNo("123008");
                                    }
                                }
                            }

                            this.equipmentOfferBo.setEoList(eoList);

//                            String dummyItemId = this.brxEomRefCodeService.getDummyItemId();
//                            
//                            if(!this.pictureMap.keySet().contains(dummyItemId)){
//                               Map<String, Picture> tempPictureMap = this.brxEomRefCodeService.getPicture(dummyItemId);
//                               
//                            }
//                            System.out.println("byte: " + this.picture.getContent().length);
                        }

                    } else {

                        this.preRegEntity = this.preRegService.getPreRegInfo(this.factorValue);

                        this.eoList = this.equipmentOfferService.getResEoByPreReg(this.factorValue);

                        if (this.eoList != null) {
                            this.isFound = true;
                        }

                    }

                } else if (this.channelType.equals("ES")) {
                    /**
                     * If channel type is ES.
                     */

                    this.equipList = this.equipmentOfferService.getEsEoByPps(this.factorValue);

                    this.customerEntity = new CustomerEntity();

                    if (this.equipList != null) {

                        this.isFound = true;

                        for (EquipmentEntity ei : this.equipList) {
                            if (ei != null) {
                                this.customerEntity.setCusName(ei.getCompany());
                                this.customerEntity.setCusStatus(ei.getCusStatus());
                                this.customerEntity.setPps(ei.getPps());
                                break;
                            }
                        }
                    }

                    if (this.customerEntity.getCusStatus() != null) {
                        if (this.customerEntity.getCusStatus().equals("S")
                                || this.customerEntity.getCusStatus().equals("D")
                                || this.customerEntity.getCusStatus().equals("B")
                                || this.customerEntity.getCusStatus().contains("1")) {
                            showErrorMessage("Not allow to replacement, because account not active.");
                        }
                    }

                }

                selectedEom = eoms.get(selectedEomIndex);

            } else {
                showErrorMessage("Please enter the factor value.");
            }

        } catch (Exception ex) {
            _logger.error(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void executeSearchNewDevice() {
        try {

            this.checkNewDevice = this.equipmentOfferService.getEsEquipment(this.newDevice, null, "A");

            //this.checkNewDevice = this.replacementService.checkNewImei(null, null, this.newDevice, null);
        } catch (Exception ex) {
            _logger.error(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void executeCharging() {

        try {

            if (this.selectedEom.getRefValue2().equals("RETURN_EQ")) {

//                CreEomOutputEntity returnMasterEOM = this.equipmentOfferService
//                                                                    .createEomMaster(null, //eomCode
//                                                                                     this.channelType, //eomChannel1
//                                                                                     this.factorType, //eomChannel2
//                                                                                     this.factorValue, //eomChannelRefNo
//                                                                                     this.selectedEom.getRefValue2(), //eomType
//                                                                                     this.remarks, //remarks;
//                                                                                     this.shopNo, //shopNo
//                                                                                     "9", //status
//                                                                                     this.username //userId
//                                                                                    );
//                
//                
//                    
//                CreEomOutputEntity returnDetailEOM = this.equipmentOfferService
//                                                                    .createEomDetail(null, //eomDetailCode 
//                                                                                     returnMasterEOM.getEomCode(), //eoCode 
//                                                                                     "testing type", //eoType1
//                                                                                     this.selectedEO.getEoCode(), // eoCode1
//                                                                                     "SC39VT3BAJCL7", //serialNo1
//                                                                                     "testing", //eoType2
//                                                                                     null, //eoCode2
//                                                                                     null, //serialNo2
//                                                                                     null, //masterEomDetailCode
//                                                                                     this.username //userId
//                                                                                    );

                EomMasterEntity master = new EomMasterEntity();
                master.setEomCode(null);
                master.setEomChannel1(this.channelType);
                master.setEomChannel2(this.factorType);
                master.setEomChannelRefNo(this.factorValue);
                master.setEomType(this.selectedEom.getRefValue2());
                master.setRemark(this.remarks);
                master.setShopNo(this.shopNo);
                master.setStatus("9");
                master.setUserId(this.username);

                EomDetailEntity detail = new EomDetailEntity();
                detail.setEomDetailCode(null);
                detail.setEomCode(null);
                detail.setEoType1(this.selectedEO.getEoType());
                detail.setEoCode1(this.selectedEO.getEoCode());
                detail.setSerialNo1(this.selectedEO.getSerialNo());
                detail.setEoType2(this.selectedEO.getEoType());
                detail.setEoCode2(null);
                detail.setSerialNo2(null);
                detail.setChargeAmount(this.selectedEO.getChargeFee());
                detail.setChargeFlag((this.selectedEO.getChargeFlag()==true)?"Y":"N");
                detail.setMasterEomDetailCode(null);
                detail.setUserId(this.username);

                List<EomDetailEntity> details = new ArrayList<>();

                for (SubItem subItem : this.selectedEO.getSubItems()) {
                    EomDetailEntity subItem2EOMdetail = new EomDetailEntity();
                    subItem2EOMdetail.setEomDetailCode(null);
                    subItem2EOMdetail.setEomCode(null);
                    subItem2EOMdetail.setEoType1("Equip");
                    subItem2EOMdetail.setEoCode1(subItem.getItemId());
                    subItem2EOMdetail.setSerialNo1(subItem.getItemId());
                    subItem2EOMdetail.setEoType2("Equip");
                    subItem2EOMdetail.setEoCode2(null);
                    subItem2EOMdetail.setSerialNo2(null);
                    subItem2EOMdetail.setMasterEomDetailCode(null);
                    subItem2EOMdetail.setChargeAmount(subItem.getChargeFee());
                    subItem2EOMdetail.setChargeFlag((subItem.getChargeFlag()==true)?"Y":"N");
                    subItem2EOMdetail.setUserId(this.username);
                    details.add(subItem2EOMdetail);
                }

                String errorMsg = this.eomService.createEom(master, detail, details);

                if (errorMsg != null && !errorMsg.isEmpty()) {
                    _logger.info("Fail to return : " + errorMsg);
                    this.showErrorMessage(errorMsg);
                    this.init();
                } else {
                    _logger.info("Successful to return.");
                    this.showSuccessMessage("Successful to return.");
                    this.init();
                }
             
            }

//            if (this.eomType.equals("Replacement")) {
//                
//                //if the device type is mobile
//                
//                /**
//                 * todo : 1. check two device type is same
//                 *
//                 * 2. if two device type is same
//                 *
//                 * 2.1 if two device type is mobile 2.1.1 check two device imei
//                 * can not be same 2.1.2 check two device item id must be same
//                 * (same model)
//                 */
//                
//                if (this.channelType.equals("Res")) {
//                    
//                    if (!this.checkInfo.getCusStatus().equals("A") && !this.checkInfo.getCusStatus().equals("S")) {
//                        showErrorMessage("Not allow to replacement, because account not active or suspense.");
//                        return;
//                    }
//                    
//                    if (this.selectedDevice.getMobileStatus().equals("D")) {
//                       showErrorMessage("Not allow to replacement, because device status is deleted.");
//                       return; 
//                    }
//
//                } else {
//                    
//                    if (this.checkInfo.getCusStatus().equals("S") || this.checkInfo.getCusStatus().equals("D") || this.checkInfo.getCusStatus().equals("B") || this.checkInfo.getCusStatus().equals("1")) {
//                        showErrorMessage("Not allow to replacement, because account not active.");
//                        return;
//                    }
//                    
//                    if (this.selectedDevice.getMobileStatus().equals("D")) {
//                       showErrorMessage("Not allow to replacement, because device status is deleted.");
//                       return; 
//                    }
//                    
//                }
//
//            }
        } catch (Exception ex) {
            _logger.error(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void onSelectChannelType(AjaxBehaviorEvent event) {
        try {
            if (!this.channelType.isEmpty()) {
                this.showFactorType = true;
                this.factors = new ArrayList<>(this.brxEomRefCodeService.findAll(new BrxEomRefCodeEntity() {
                    {
                        setRefType("EOM_CHANNEL_2");
                        setRefCode(channelType);
                    }
                }));
            } else {
                this.showFactorType = false;
            }
        } catch (Exception ex) {
            _logger.error(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void onSelectFactor(AjaxBehaviorEvent event) {
        try {
            if (this.factorType != null && !this.factorType.isEmpty()) {
                this.eoms = new ArrayList<>(this.brxEomRefCodeService.findAll(new BrxEomRefCodeEntity() {
                    {
                        setRefType("EOM_TYPE");
                        setRefCode(channelType);
                        setRefValue1(factorType);
                    }
                }));
            }
        } catch (Exception ex) {
            _logger.error(ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void onSelectedDevice(EquipmentEntity equipmentInfo) {
        for (EquipmentEntity ei : this.checkInfo.getEquipList()) {
            if (equipmentInfo.getImei().equals(ei.getImei())) {
                ei.setSelected(true);
                this.selectedDevice = equipmentInfo;
            } else {
                ei.setSelected(false);
            }
        }
    }

    public String getDateTime(String date) {
        if (date.length() != 0) {
            return new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date(Long.valueOf(date).longValue()));
        }
        return "";
    }

    public void setSalesShopNo(String username) {
        if (username != null) {
            this.username = username;
            this.shopNo = this.bnShopStaffService.getStaffShopNo(username);
        }
    }

    public void filterSerialNoListener() {
        try {
            if (this.isFound == true) {
                if (this.serialNoFilter != null && !this.serialNoFilter.isEmpty()) {
                    this.eoList = this.equipmentOfferBo.getEoList().stream()
                            .filter(p -> p.getSerialNo().contains(serialNoFilter)).collect(Collectors.toList());
                } else {
                    this.eoList = this.equipmentOfferBo.getEoList();
                }
            }
        } catch (Exception ex) {
            _logger.error(ex.getMessage());
        }
    }

    public List<BrxEomRefCodeEntity> getChannels() {
        return channels;
    }

    public void setChannels(List<BrxEomRefCodeEntity> channels) {
        this.channels = channels;
    }

    public List<BrxEomRefCodeEntity> getFactors() {
        return factors;
    }

    public void setFactors(List<BrxEomRefCodeEntity> factors) {
        this.factors = factors;
    }

    public List<BrxEomRefCodeEntity> getEoms() {
        return eoms;
    }

    public void setEoms(List<BrxEomRefCodeEntity> eoms) {
        this.eoms = eoms;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getFactorType() {
        return factorType;
    }

    public void setFactorType(String factorType) {
        this.factorType = factorType;
    }

    public String getFactorValue() {
        return factorValue;
    }

    public void setFactorValue(String factorValue) {
        this.factorValue = factorValue;
    }

    public BrxEomRefCodeEntity getSelectedEom() {
        return selectedEom;
    }

    public void setSelectedEom(BrxEomRefCodeEntity selectedEom) {
        this.selectedEom = selectedEom;
    }

    public List<EOEntity> getEoList() {
        return eoList;
    }

    public EOEntity getSelectedEO() {
        return selectedEO;
    }

    public void setSelectedEO(EOEntity selectedEO) {
        this.selectedEO = selectedEO;
    }

    public List<EquipmentEntity> getEquipList() {
        return equipList;
    }

    public void setEquipList(List<EquipmentEntity> equipList) {
        this.equipList = equipList;
    }

    public void setEoList(List<EOEntity> eoList) {
        this.eoList = eoList;
    }

    public String getNewDevice() {
        return newDevice;
    }

    public void setNewDevice(String newDevice) {
        this.newDevice = newDevice;
    }

    public String getChargeOption() {
        return chargeOption;
    }

    public void setChargeOption(String chargeOption) {
        this.chargeOption = chargeOption;
    }

    public boolean isShowFactorType() {
        return showFactorType;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setShowFactorType(boolean showFactorType) {
        this.showFactorType = showFactorType;
    }

    public ReplacementCheckEntity getCheckInfo() {
        return checkInfo;
    }

    public CustomerEntity getCustomerEntity() {
        return customerEntity;
    }

    public void setCustomerEntity(CustomerEntity customerEntity) {
        this.customerEntity = customerEntity;
    }

    public PreRegEntity getPreRegEntity() {
        return preRegEntity;
    }

    public void setPreRegEntity(PreRegEntity preRegEntity) {
        this.preRegEntity = preRegEntity;
    }

    public void setCheckInfo(ReplacementCheckEntity checkInfo) {
        this.checkInfo = checkInfo;
    }

    public EquipmentEntity getSelectedDevice() {
        return selectedDevice;
    }

    public void setSelectedDevice(EquipmentEntity selectedDevice) {
        this.selectedDevice = selectedDevice;
    }

    public EquipmentEntity getCheckNewDevice() {
        return checkNewDevice;
    }

    public void setCheckNewDevice(EquipmentEntity checkNewDevice) {
        this.checkNewDevice = checkNewDevice;
    }

    public boolean isIsFound() {
        return isFound;
    }

    public void setIsFound(boolean isFound) {
        this.isFound = isFound;
    }

    public String getEomType() {
        return eomType;
    }

    public void setEomType(String eomType) {
        this.eomType = eomType;
    }

    public Integer getSelectedEomIndex() {
        return selectedEomIndex;
    }

    public void setSelectedEomIndex(Integer selectedEomIndex) {
        this.selectedEomIndex = selectedEomIndex;
    }

    public EquipmentEntity getEquipment(EOEntity eo) {
        if (eo != null) {

            EquipmentEntity entity = new EquipmentEntity();

            entity = (EquipmentEntity) eo;

            return entity;
        } else {
            return null;
        }
    }

    public OfferEntity getOffer(EOEntity eo) {
        if (eo != null) {
            return (OfferEntity) eo;
        } else {
            return null;
        }
    }

    public boolean renderEO(String panelType, String eoType) {
        return (panelType != null || eoType != null) ? panelType.equals(eoType) : false;
    }

    public DefaultStreamedContent getPic() {
        return pic;
    }

    public void setPic(DefaultStreamedContent pic) {
        this.pic = pic;
    }

    public String getSerialNoFilter() {
        return serialNoFilter;
    }

    public void setSerialNoFilter(String serialNoFilter) {
        this.serialNoFilter = serialNoFilter;
    }

}
