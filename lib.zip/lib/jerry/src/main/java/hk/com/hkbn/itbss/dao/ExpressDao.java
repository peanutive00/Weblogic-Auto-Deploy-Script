/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao;

import hk.com.hkbn.itbss.entity.CreateOrder2Entity;
import java.sql.SQLException;

/**
 * @author itbssvendor02
 */
public interface ExpressDao {

    String createOrder(CreateOrder2Entity createOrder2Entity) throws SQLException;
    
}
