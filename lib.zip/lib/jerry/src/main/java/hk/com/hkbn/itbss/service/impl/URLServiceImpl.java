/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.dao.URLDao;
import hk.com.hkbn.itbss.dao.impl.URLDaoImpl;
import hk.com.hkbn.itbss.service.URLService;
import java.sql.SQLException;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;

/**
 *
 * @author itbssvendor01
 */
@Stateless
@LocalBean
public class URLServiceImpl implements URLService {
    
    private org.slf4j.Logger _logger = org.slf4j.LoggerFactory.getLogger(URLServiceImpl.class);

    @Resource(name = "jdbc.hkbn")
    private DataSource ds;
    
    private URLDao dao;
    
    public URLServiceImpl() {
        
    }
    
    public URLServiceImpl(URLDao dao) {
        this.dao = dao;
    }
    
    @PostConstruct
    private void init() {
        this.dao = new URLDaoImpl(ds);
    }
    
    @Override
    public String getWebServiceURL(String refType, String refCode) throws SQLException {
        return dao.getWebServiceURL(refType, refCode);
    }
    
}
