package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.CustomerDao;
import hk.com.hkbn.itbss.entity.CustomerEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

/**
 * @description:
 * @author: leon.cheung
 * @create: 25-04-2018
 **/
public class CustomerDaoImpl implements CustomerDao {


  private org.slf4j.Logger _logger = org.slf4j.LoggerFactory.getLogger(CustomerDaoImpl.class);

  private final DataSource ds;

  public CustomerDaoImpl(DataSource ds) {
    this.ds = ds;
  }


  @Override
  public CustomerEntity getCustomer(String pps) throws SQLException {
    {

      Connection connection = ds.getConnection();

      String sql = "select pps,pri_code,surname,given_name,status from bn_cus where pps=?";

      CustomerEntity customerEntity = null;

      try {

        PreparedStatement statement = connection.prepareStatement(sql);

        if (pps != null && !pps.isEmpty()) {
          statement.setString(1, pps);
        }
        try {

          ResultSet rs = statement.executeQuery();

          try {

            if (rs.next()) {
              customerEntity = new CustomerEntity();
              customerEntity.setPps(rs.getString("pps"));
              customerEntity.setCusPriCode(Long.parseLong(rs.getString("pri_code")));
              customerEntity.setCusName(rs.getString("surname") + " " + rs.getString("given_name"));
              customerEntity.setCusStatus(rs.getString("status"));
            }

            return customerEntity;

          } catch (SQLException ex) {
            _logger.error(ex.getMessage());
            return null;
          }

        } catch (SQLException ex) {
          _logger.error(ex.getMessage());
          return null;
        } finally {
          statement.close();
        }

      } catch (SQLException ex) {
        _logger.error(ex.getMessage());
        return null;
      } finally {
        connection.close();
      }

    }
  }
}
