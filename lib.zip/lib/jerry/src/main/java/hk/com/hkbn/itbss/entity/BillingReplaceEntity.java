package hk.com.hkbn.itbss.entity;


import java.sql.Date;

/**
 * @description:
 * @author: leon.cheung
 * @create: 16-04-2018
 **/
public class BillingReplaceEntity {

  private String serviceType;

  private String serviceCode;

  private String equipType;
  private String oldSerialNo;

  private String newSerialNo;
  private Date replaceDate;
  private String shopNo;
  private String staffAmend;

  public String getServiceType() {
    return serviceType;
  }

  public void setServiceType(String serviceType) {
    this.serviceType = serviceType;
  }

  public String getServiceCode() {
    return serviceCode;
  }

  public void setServiceCode(String serviceCode) {
    this.serviceCode = serviceCode;
  }

  public String getEquipType() {
    return equipType;
  }

  public void setEquipType(String equipType) {
    this.equipType = equipType;
  }

  public String getOldSerialNo() {
    return oldSerialNo;
  }

  public void setOldSerialNo(String oldSerialNo) {
    this.oldSerialNo = oldSerialNo;
  }

  public String getNewSerialNo() {
    return newSerialNo;
  }

  public void setNewSerialNo(String newSerialNo) {
    this.newSerialNo = newSerialNo;
  }

  public Date getReplaceDate() {
    return replaceDate;
  }

  public void setReplaceDate(Date replaceDate) {
    this.replaceDate = replaceDate;
  }

  public String getShopNo() {
    return shopNo;
  }

  public void setShopNo(String shopNo) {
    this.shopNo = shopNo;
  }

  public String getStaffAmend() {
    return staffAmend;
  }

  public void setStaffAmend(String staffAmend) {
    this.staffAmend = staffAmend;
  }
}
