/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.EquipmentOfferDao;
import hk.com.hkbn.itbss.entity.BillingReplaceEntity;
import hk.com.hkbn.itbss.entity.EOEntity;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import hk.com.hkbn.itbss.entity.OfferEntity;
import hk.com.hkbn.itbss.entity.Picture;
import java.io.ByteArrayInputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

/**
 *
 * @author itbssvendor01
 */
public class EquipmentOfferDaoImpl implements EquipmentOfferDao {

    private final DataSource ds;

    public EquipmentOfferDaoImpl(DataSource ds) {
        this.ds = ds;
    }
    
    @Override
    public List<EOEntity> getResEoByPps(String pps) throws SQLException {
        String query = "SELECT 'General Offer' AS eo_for, "
                     + "       'N/A' AS eo_value, "
                     + "       offer_code, "
                     + "       'Offer' AS eo_type "
                     + "FROM brx_cus_offer "
                     + "WHERE redemp_flag <> 'Y' "
                     + "  AND cus_pri_code = (SELECT pri_code "
                     + "                      FROM bn_cus "
                     + "                      WHERE pps = ?) "
                     + "UNION "
                     + "SELECT 'Service Offer' AS eo_for, "
                     + "       service_type AS eo_value, "
                     + "       offer_code, "
                     + "       'Offer' AS eo_type "
                     + "FROM brx_ace_offer "
                     + "WHERE redemp_flag <> 'Y' "
                     + "  AND cus_pri_code = (SELECT pri_code "
                     + "                      FROM bn_cus "
                     + "                      WHERE pps = ?) ";
        
        Connection con = null;
        PreparedStatement ps = null;
        
        List<EOEntity> list = new ArrayList<>();
        try {
            
            con = ds.getConnection();
            ps = con.prepareStatement(query);
            
            ps.setString(1, pps);
            ps.setString(2, pps);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                EOEntity entity;
                if (rs.getString("eo_type").equals("Offer")) {
                    entity = new OfferEntity();
                    entity.setEoFor(rs.getString("eo_for"));
                    entity.setEoValue(rs.getString("eo_value"));
                    entity.setEoCode(rs.getString("offer_code"));
                    entity.setEoType(rs.getString("eo_type"));
                } else {
                    entity = new EquipmentEntity();
                    entity.setEoFor(rs.getString("eo_for"));
                    entity.setEoValue(rs.getString("eo_value"));
                    entity.setEoCode(rs.getString("offer_code"));
                    entity.setEoType(rs.getString("eo_type"));
                }
                list.add(entity);
            }
            
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
        return list;
    }
    
    @Override
    public List<EOEntity> getResEoByPreReg(String preRegCode) throws SQLException {
        String query = "SELECT 'Pre-reg' AS eo_for, "
                     + "       pre_reg_code AS eo_value, "
                     + "       offer_code, "
                     + "       'Offer' AS eo_type "
                     + "FROM bn_pre_reg_offer pro "
                     + "WHERE pro.pre_reg_code = ? ";
        
        Connection con = null;
        PreparedStatement ps = null;
        
        List<EOEntity> list = new ArrayList<>();
        try {
            
            con = ds.getConnection();
            ps = con.prepareStatement(query);
            
            ps.setString(1, preRegCode);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                EOEntity entity = new OfferEntity();
                entity.setEoFor(rs.getString("eo_for"));
                entity.setEoValue(rs.getString("eo_value"));
                entity.setEoCode(rs.getString("offer_code"));
                entity.setEoType(rs.getString("eo_type"));
                list.add(entity);
            }
            
        } finally {
            if (ps != null)
                ps.close();
            if (con != null)
                con.close();
        }
        return list;
    }
    
    @Override
    public EquipmentEntity getEsEquipmentEntity(String imei, String serialNo, String status) throws SQLException {
        String sql = "SELECT a.item_id, "
                   + "       a.part_no, "
                   + "       a.imei, "
                   + "       a.serial_no, "
                   + "       b.desc_chi, "
                   + "       b.desc_eng "
                   + "FROM cm_stock_detail@sso.sso a, "
                   + "     cm_item@sso.sso b "
                   + "WHERE a.imei = NVL(?, a.imei) "
                   + "  AND a.serial_no = NVL(?, a.serial_no) "
                   + "  AND a.part_no = b.part_no "
                   + "  AND a.status = NVL(?, a.status) "
                   + "  AND rownum = 1 ";

        EquipmentEntity equipmentInfo = new EquipmentEntity();
        Connection connection = null;
        PreparedStatement statement = null;

        try {

            connection = ds.getConnection();
            statement = connection.prepareStatement(sql);

            statement.setString(1, imei);
            statement.setString(2, serialNo);
            statement.setString(3, status);

            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                equipmentInfo.setItemId(rs.getString("ITEM_ID"));
                equipmentInfo.setPartNo(rs.getString("PART_NO"));
                equipmentInfo.setImei(rs.getString("IMEI"));
                equipmentInfo.setSerialNo(rs.getString("SERIAL_NO"));
                equipmentInfo.setDescChi(rs.getString("DESC_CHI"));
                equipmentInfo.setDescEng(rs.getString("DESC_ENG"));
            }

            return equipmentInfo;

        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null)
                connection.close();
        }
    }

    @Override
    public String replaceEquip(BillingReplaceEntity billingReplaceEntity) throws SQLException {

        Connection connection = null;
        CallableStatement cst = null;
        try {

            connection = ds.getConnection();

            String proc = "{call pkg_brx_service_equip.p_replace_equip(?,?,?,?,?,sysdate,?,?,?)";

            cst = connection.prepareCall(proc);

            cst.setString(1, billingReplaceEntity.getServiceType());
            cst.setString(2, billingReplaceEntity.getServiceCode());
            cst.setString(3, billingReplaceEntity.getEquipType());
            cst.setString(4, billingReplaceEntity.getOldSerialNo());
            cst.setString(5, billingReplaceEntity.getNewSerialNo());
            cst.setString(6, billingReplaceEntity.getShopNo());
            cst.setString(7, billingReplaceEntity.getStaffAmend());

            cst.registerOutParameter(8, Types.VARCHAR);

            cst.execute();

            return cst.getString(9);

        } finally {
            if (cst != null)
                cst.close();
            if (connection != null)
                connection.close();
        }
    }

    @Override
    public String getServiceNobyImei(String imei) throws SQLException {
        
        if (imei == null || imei.isEmpty())
            return null;

        String sql = "SELECT service_code "
                   + "FROM brx_service_equip_gpwf "
                   + "WHERE serial_no = ? "
                   + "  AND equip_type = 'H' "
                   + "  AND return_flag IS NULL ";
        
        Connection connection = null;
        PreparedStatement statement = null;

        try {

            connection = ds.getConnection();
            statement = connection.prepareStatement(sql);

            statement.setString(1, imei);

            ResultSet rs = statement.executeQuery();

            return rs.getString("service_code");
            

        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null)
                connection.close();
        }
    }
    
    @Override
    public Map<String, Picture> getPictureMap(List<String> itemIdList) throws SQLException {
        if (itemIdList == null)
            return null;
        
        Map<String, Picture> map = new HashMap<>();
        
        if (itemIdList.isEmpty())
            return map;
        
        String in = "?";
        for (int i = 1; i < itemIdList.size(); i++)
            in += ", ?";
        String query = "SELECT item_id, "
                     + "       img "
                     + "FROM cm_item_templet_mv "
                     + "WHERE item_id IN (" + in + ") ";
        
        Connection connection = null;
        PreparedStatement statement = null;

        try {

            connection = ds.getConnection();
            statement = connection.prepareStatement(query);
            
            int i = 1;
            for (String itemId: itemIdList) {
                statement.setString(i++, itemId);
            }
            
            ResultSet rs = statement.executeQuery();
            
            while (rs.next()) {
                Picture pic = new Picture();
                
                pic.setContent(new ByteArrayInputStream(rs.getBytes("img")));
                
                map.put(rs.getString("item_id"), pic);
            }
            
            return map;
            
        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null)
                connection.close();
        }
    }
    
    @Override
    public Picture getPicture(String itemId) throws SQLException {
        if (itemId == null)
            return null;
        
        String query = "SELECT img "
                     + "FROM cm_item_templet_mv "
                     + "WHERE item_id = ? ";
        
        Connection connection = null;
        PreparedStatement statement = null;

        try {

            connection = ds.getConnection();
            statement = connection.prepareStatement(query);
            
            statement.setString(1, itemId);
            
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()) {
                Picture pic = new Picture();
                pic.setContent(new ByteArrayInputStream(rs.getBytes("img")));
                return pic;
            } else {
                return null;
            }
            
        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null)
                connection.close();
        }
    }
    
    @Override
    public String getDummyItemId() throws SQLException {
        
        String query = "SELECT ref_value1 "
                     + "FROM brx_eom_ref_code "
                     + "WHERE ref_type = 'EO_IMAGE' "
                     + "  AND ref_code = 'DUMMY_IMAGE_ITEM_ID' ";
        
        Connection connection = null;
        PreparedStatement statement = null;

        try {

            connection = ds.getConnection();
            statement = connection.prepareStatement(query);
            
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()) {
                return rs.getString("ref_value1");
            } else {
                return null;
            }
            
        } catch (SQLException ex) {
//            _logger.error(ex.getMessage());
            throw ex;
        } finally {
            if (statement != null)
                statement.close();
            if (connection != null)
                connection.close();
        }
    }
    
}
