/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao;

import hk.com.hkbn.itbss.entity.EomDetailEntity;
import hk.com.hkbn.itbss.entity.EomMasterEntity;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author itbssvendor01
 */
public interface EomDao {
    
    public String createEom(EomMasterEntity eomMasterEntity, EomDetailEntity eomDetailEntity, List<EomDetailEntity> subItemList) throws SQLException;
    
}
