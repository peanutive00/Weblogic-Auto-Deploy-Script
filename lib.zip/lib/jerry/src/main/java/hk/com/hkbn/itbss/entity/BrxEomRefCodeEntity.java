/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

import java.util.Date;

/**
 *
 * @author itbssvendor01
 */
public class BrxEomRefCodeEntity {

    private String refType;
    private String refCode;
    private String refDesc;
    private String remarks;
    private String refValue1;
    private String refValue2;
    private String refValue3;
    private String refValue4;
    private String refValue5;
    private String refValue6;
    private java.util.Date createDate;

    public String getRefType() {
        return refType;
    }

    public void setRefType(String refType) {
        this.refType = refType;
    }

    public String getRefCode() {
        return refCode;
    }

    public void setRefCode(String refCode) {
        this.refCode = refCode;
    }

    public String getRefDesc() {
        return refDesc;
    }

    public void setRefDesc(String refDesc) {
        this.refDesc = refDesc;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRefValue1() {
        return refValue1;
    }

    public void setRefValue1(String refValue1) {
        this.refValue1 = refValue1;
    }

    public String getRefValue2() {
        return refValue2;
    }

    public void setRefValue2(String refValue2) {
        this.refValue2 = refValue2;
    }

    public String getRefValue3() {
        return refValue3;
    }

    public void setRefValue3(String refValue3) {
        this.refValue3 = refValue3;
    }

    public String getRefValue4() {
        return refValue4;
    }

    public void setRefValue4(String refValue4) {
        this.refValue4 = refValue4;
    }

    public String getRefValue5() {
        return refValue5;
    }

    public void setRefValue5(String refValue5) {
        this.refValue5 = refValue5;
    }

    public String getRefValue6() {
        return refValue6;
    }

    public void setRefValue6(String refValue6) {
        this.refValue6 = refValue6;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        if(createDate != null)
            this.createDate = new java.util.Date(createDate.getTime());
    }
    
}
