package hk.com.hkbn.itbss.entity;

/**
 * @description:
 * @author: leon.cheung
 * @create: 13-04-2018
 **/
public class CreateOrder2Entity {

  private String inChannel1;
  private String inChannel2;
  private String inChannelRefNo;
  private String inPps;
  private String inOrderDate;
  private String inOrderTimeFrame;
  private String inAddr1;
  private String inAddr2;
  private String inAddr3;
  private String inAddr4;
  private String inDistrictCode;
  private String inContactName;
  private String inContactTel;
  private String inOrderType;
  private String inAlertMsg;
  private String inStatus;
  private String inAddressCode;
  private String inFloor;
  private String inFlat;
  private String inStaffCreate;
  private String inSalesCode;
  private String inShopNo;
  private String inWaiveFlag;
  private String inChargeAmount;
  private String inQuotaReserverRef;
  private String inAuthCode;
  private String inItemId1;
  private String inItemCode1;
  private String inModel1;
  private String inVersion1;
  private String inOfferCode1;
  private String inQty1;
  private String inItemType1;
  private String inServiceType1;
  private String inSerialNo1;
  private String inItemId2;
  private String inItemCode2;
  private String inModel2;
  private String inVersion2;
  private String inOfferCode2;
  private String inQty2;
  private String inItemType2;
  private String inServiceType2;
  private String inSerialNo2;
  private String inItemId3;
  private String inItemCode3;
  private String inModel3;
  private String inVersion3;
  private String inOfferCode3;
  private String inQty3;
  private String inItemType3;
  private String inServiceType3;
  private String inSerialNo3;
  private String inItemId4;
  private String inItemCode4;
  private String inModel4;
  private String inVersion4;
  private String inOfferCode4;
  private String inQty4;
  private String inItemType4;
  private String inServiceType4;
  private String inSerialNo4;
  private String inItemId5;
  private String inItemCode5;
  private String inModel5;
  private String inVersion5;
  private String inOfferCode5;
  private String inQty5;
  private String inItemType5;
  private String inServiceType5;
  private String inSerialNo5;
  private String outMessage;

  public String getInChannel1() {
    return inChannel1;
  }

  public void setInChannel1(String inChannel1) {
    this.inChannel1 = inChannel1;
  }

  public String getInChannel2() {
    return inChannel2;
  }

  public void setInChannel2(String inChannel2) {
    this.inChannel2 = inChannel2;
  }

  public String getInChannelRefNo() {
    return inChannelRefNo;
  }

  public void setInChannelRefNo(String inChannelRefNo) {
    this.inChannelRefNo = inChannelRefNo;
  }

  public String getInPps() {
    return inPps;
  }

  public void setInPps(String inPps) {
    this.inPps = inPps;
  }

  public String getInOrderDate() {
    return inOrderDate;
  }

  public void setInOrderDate(String inOrderDate) {
    this.inOrderDate = inOrderDate;
  }

  public String getInOrderTimeFrame() {
    return inOrderTimeFrame;
  }

  public void setInOrderTimeFrame(String inOrderTimeFrame) {
    this.inOrderTimeFrame = inOrderTimeFrame;
  }

  public String getInAddr1() {
    return inAddr1;
  }

  public void setInAddr1(String inAddr1) {
    this.inAddr1 = inAddr1;
  }

  public String getInAddr2() {
    return inAddr2;
  }

  public void setInAddr2(String inAddr2) {
    this.inAddr2 = inAddr2;
  }

  public String getInAddr3() {
    return inAddr3;
  }

  public void setInAddr3(String inAddr3) {
    this.inAddr3 = inAddr3;
  }

  public String getInAddr4() {
    return inAddr4;
  }

  public void setInAddr4(String inAddr4) {
    this.inAddr4 = inAddr4;
  }

  public String getInDistrictCode() {
    return inDistrictCode;
  }

  public void setInDistrictCode(String inDistrictCode) {
    this.inDistrictCode = inDistrictCode;
  }

  public String getInContactName() {
    return inContactName;
  }

  public void setInContactName(String inContactName) {
    this.inContactName = inContactName;
  }

  public String getInContactTel() {
    return inContactTel;
  }

  public void setInContactTel(String inContactTel) {
    this.inContactTel = inContactTel;
  }

  public String getInOrderType() {
    return inOrderType;
  }

  public void setInOrderType(String inOrderType) {
    this.inOrderType = inOrderType;
  }

  public String getInAlertMsg() {
    return inAlertMsg;
  }

  public void setInAlertMsg(String inAlertMsg) {
    this.inAlertMsg = inAlertMsg;
  }

  public String getInStatus() {
    return inStatus;
  }

  public void setInStatus(String inStatus) {
    this.inStatus = inStatus;
  }

  public String getInAddressCode() {
    return inAddressCode;
  }

  public void setInAddressCode(String inAddressCode) {
    this.inAddressCode = inAddressCode;
  }

  public String getInFloor() {
    return inFloor;
  }

  public void setInFloor(String inFloor) {
    this.inFloor = inFloor;
  }

  public String getInFlat() {
    return inFlat;
  }

  public void setInFlat(String inFlat) {
    this.inFlat = inFlat;
  }

  public String getInStaffCreate() {
    return inStaffCreate;
  }

  public void setInStaffCreate(String inStaffCreate) {
    this.inStaffCreate = inStaffCreate;
  }

  public String getInSalesCode() {
    return inSalesCode;
  }

  public void setInSalesCode(String inSalesCode) {
    this.inSalesCode = inSalesCode;
  }

  public String getInShopNo() {
    return inShopNo;
  }

  public void setInShopNo(String inShopNo) {
    this.inShopNo = inShopNo;
  }

  public String getInWaiveFlag() {
    return inWaiveFlag;
  }

  public void setInWaiveFlag(String inWaiveFlag) {
    this.inWaiveFlag = inWaiveFlag;
  }

  public String getInChargeAmount() {
    return inChargeAmount;
  }

  public void setInChargeAmount(String inChargeAmount) {
    this.inChargeAmount = inChargeAmount;
  }

  public String getInQuotaReserverRef() {
    return inQuotaReserverRef;
  }

  public void setInQuotaReserverRef(String inQuotaReserverRef) {
    this.inQuotaReserverRef = inQuotaReserverRef;
  }

  public String getInAuthCode() {
    return inAuthCode;
  }

  public void setInAuthCode(String inAuthCode) {
    this.inAuthCode = inAuthCode;
  }

  public String getInItemId1() {
    return inItemId1;
  }

  public void setInItemId1(String inItemId1) {
    this.inItemId1 = inItemId1;
  }

  public String getInItemCode1() {
    return inItemCode1;
  }

  public void setInItemCode1(String inItemCode1) {
    this.inItemCode1 = inItemCode1;
  }

  public String getInModel1() {
    return inModel1;
  }

  public void setInModel1(String inModel1) {
    this.inModel1 = inModel1;
  }

  public String getInVersion1() {
    return inVersion1;
  }

  public void setInVersion1(String inVersion1) {
    this.inVersion1 = inVersion1;
  }

  public String getInOfferCode1() {
    return inOfferCode1;
  }

  public void setInOfferCode1(String inOfferCode1) {
    this.inOfferCode1 = inOfferCode1;
  }

  public String getInQty1() {
    return inQty1;
  }

  public void setInQty1(String inQty1) {
    this.inQty1 = inQty1;
  }

  public String getInItemType1() {
    return inItemType1;
  }

  public void setInItemType1(String inItemType1) {
    this.inItemType1 = inItemType1;
  }

  public String getInServiceType1() {
    return inServiceType1;
  }

  public void setInServiceType1(String inServiceType1) {
    this.inServiceType1 = inServiceType1;
  }

  public String getInSerialNo1() {
    return inSerialNo1;
  }

  public void setInSerialNo1(String inSerialNo1) {
    this.inSerialNo1 = inSerialNo1;
  }

  public String getInItemId2() {
    return inItemId2;
  }

  public void setInItemId2(String inItemId2) {
    this.inItemId2 = inItemId2;
  }

  public String getInItemCode2() {
    return inItemCode2;
  }

  public void setInItemCode2(String inItemCode2) {
    this.inItemCode2 = inItemCode2;
  }

  public String getInModel2() {
    return inModel2;
  }

  public void setInModel2(String inModel2) {
    this.inModel2 = inModel2;
  }

  public String getInVersion2() {
    return inVersion2;
  }

  public void setInVersion2(String inVersion2) {
    this.inVersion2 = inVersion2;
  }

  public String getInOfferCode2() {
    return inOfferCode2;
  }

  public void setInOfferCode2(String inOfferCode2) {
    this.inOfferCode2 = inOfferCode2;
  }

  public String getInQty2() {
    return inQty2;
  }

  public void setInQty2(String inQty2) {
    this.inQty2 = inQty2;
  }

  public String getInItemType2() {
    return inItemType2;
  }

  public void setInItemType2(String inItemType2) {
    this.inItemType2 = inItemType2;
  }

  public String getInServiceType2() {
    return inServiceType2;
  }

  public void setInServiceType2(String inServiceType2) {
    this.inServiceType2 = inServiceType2;
  }

  public String getInSerialNo2() {
    return inSerialNo2;
  }

  public void setInSerialNo2(String inSerialNo2) {
    this.inSerialNo2 = inSerialNo2;
  }

  public String getInItemId3() {
    return inItemId3;
  }

  public void setInItemId3(String inItemId3) {
    this.inItemId3 = inItemId3;
  }

  public String getInItemCode3() {
    return inItemCode3;
  }

  public void setInItemCode3(String inItemCode3) {
    this.inItemCode3 = inItemCode3;
  }

  public String getInModel3() {
    return inModel3;
  }

  public void setInModel3(String inModel3) {
    this.inModel3 = inModel3;
  }

  public String getInVersion3() {
    return inVersion3;
  }

  public void setInVersion3(String inVersion3) {
    this.inVersion3 = inVersion3;
  }

  public String getInOfferCode3() {
    return inOfferCode3;
  }

  public void setInOfferCode3(String inOfferCode3) {
    this.inOfferCode3 = inOfferCode3;
  }

  public String getInQty3() {
    return inQty3;
  }

  public void setInQty3(String inQty3) {
    this.inQty3 = inQty3;
  }

  public String getInItemType3() {
    return inItemType3;
  }

  public void setInItemType3(String inItemType3) {
    this.inItemType3 = inItemType3;
  }

  public String getInServiceType3() {
    return inServiceType3;
  }

  public void setInServiceType3(String inServiceType3) {
    this.inServiceType3 = inServiceType3;
  }

  public String getInSerialNo3() {
    return inSerialNo3;
  }

  public void setInSerialNo3(String inSerialNo3) {
    this.inSerialNo3 = inSerialNo3;
  }

  public String getInItemId4() {
    return inItemId4;
  }

  public void setInItemId4(String inItemId4) {
    this.inItemId4 = inItemId4;
  }

  public String getInItemCode4() {
    return inItemCode4;
  }

  public void setInItemCode4(String inItemCode4) {
    this.inItemCode4 = inItemCode4;
  }

  public String getInModel4() {
    return inModel4;
  }

  public void setInModel4(String inModel4) {
    this.inModel4 = inModel4;
  }

  public String getInVersion4() {
    return inVersion4;
  }

  public void setInVersion4(String inVersion4) {
    this.inVersion4 = inVersion4;
  }

  public String getInOfferCode4() {
    return inOfferCode4;
  }

  public void setInOfferCode4(String inOfferCode4) {
    this.inOfferCode4 = inOfferCode4;
  }

  public String getInQty4() {
    return inQty4;
  }

  public void setInQty4(String inQty4) {
    this.inQty4 = inQty4;
  }

  public String getInItemType4() {
    return inItemType4;
  }

  public void setInItemType4(String inItemType4) {
    this.inItemType4 = inItemType4;
  }

  public String getInServiceType4() {
    return inServiceType4;
  }

  public void setInServiceType4(String inServiceType4) {
    this.inServiceType4 = inServiceType4;
  }

  public String getInSerialNo4() {
    return inSerialNo4;
  }

  public void setInSerialNo4(String inSerialNo4) {
    this.inSerialNo4 = inSerialNo4;
  }

  public String getInItemId5() {
    return inItemId5;
  }

  public void setInItemId5(String inItemId5) {
    this.inItemId5 = inItemId5;
  }

  public String getInItemCode5() {
    return inItemCode5;
  }

  public void setInItemCode5(String inItemCode5) {
    this.inItemCode5 = inItemCode5;
  }

  public String getInModel5() {
    return inModel5;
  }

  public void setInModel5(String inModel5) {
    this.inModel5 = inModel5;
  }

  public String getInVersion5() {
    return inVersion5;
  }

  public void setInVersion5(String inVersion5) {
    this.inVersion5 = inVersion5;
  }

  public String getInOfferCode5() {
    return inOfferCode5;
  }

  public void setInOfferCode5(String inOfferCode5) {
    this.inOfferCode5 = inOfferCode5;
  }

  public String getInQty5() {
    return inQty5;
  }

  public void setInQty5(String inQty5) {
    this.inQty5 = inQty5;
  }

  public String getInItemType5() {
    return inItemType5;
  }

  public void setInItemType5(String inItemType5) {
    this.inItemType5 = inItemType5;
  }

  public String getInServiceType5() {
    return inServiceType5;
  }

  public void setInServiceType5(String inServiceType5) {
    this.inServiceType5 = inServiceType5;
  }

  public String getInSerialNo5() {
    return inSerialNo5;
  }

  public void setInSerialNo5(String inSerialNo5) {
    this.inSerialNo5 = inSerialNo5;
  }

  public String getOutMessage() {
    return outMessage;
  }

  public void setOutMessage(String outMessage) {
    this.outMessage = outMessage;
  }
}
