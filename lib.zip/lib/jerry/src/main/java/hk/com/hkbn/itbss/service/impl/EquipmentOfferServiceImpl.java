/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import hk.com.hkbn.itbss.constants.CommonConstants;
import hk.com.hkbn.itbss.dao.EquipmentOfferDao;
import hk.com.hkbn.itbss.dao.impl.EquipmentOfferDaoImpl;
import hk.com.hkbn.itbss.entity.BillingReplaceEntity;
import hk.com.hkbn.itbss.entity.CreateOrder2Entity;
import hk.com.hkbn.itbss.entity.EOEntity;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import hk.com.hkbn.itbss.entity.Picture;
import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import hk.com.hkbn.itbss.entry.EsMobileResponse;
import hk.com.hkbn.itbss.entry.FindImeiRequest;
import hk.com.hkbn.itbss.entry.UpdateImeiRequest;
import hk.com.hkbn.itbss.httpClient.ClientHelper;
import hk.com.hkbn.itbss.service.EquipmentOfferService;
import hk.com.hkbn.itbss.service.ExpressService;
import hk.com.hkbn.itbss.service.LogActionService;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor01
 */
@Stateless
@LocalBean
public class EquipmentOfferServiceImpl implements EquipmentOfferService {
    
    private final Logger _logger = LoggerFactory.getLogger(EquipmentOfferServiceImpl.class);
    
    @Resource(name = "jdbc.hkbn_omtest")
    private DataSource ds;
    
    @EJB
    private ExpressService expressService;
    
    @EJB
    private LogActionService logActionService;
    
    private EquipmentOfferDao dao;
    
    public EquipmentOfferServiceImpl() {    
    }
    
    public EquipmentOfferServiceImpl(EquipmentOfferDao dao) {
        this.dao = dao;
    }
    
    @PostConstruct
    private void init() {
        this.dao = new EquipmentOfferDaoImpl(ds);
    }
    
    @Override
    public List<EOEntity> getResEoByPps(String pps) throws SQLException {
        return dao.getResEoByPps(pps);
    }
    
    @Override
    public List<EOEntity> getResEoByPreReg(String preRegCode) throws SQLException {
        return dao.getResEoByPreReg(preRegCode);
    }
    
    @Override
    public List<EquipmentEntity> getEsEoByPps(String pps) throws Exception {
        if (StringUtils.isEmpty(pps))
            return null;
        
        FindImeiRequest request = new FindImeiRequest();
        request.setPlatform(CommonConstants.ES);
        request.setPps(pps);
        
        return this.getEsEquipment(request);
    }
    
    @Override
    public List<EquipmentEntity> getEsEoByImei(String imei) throws Exception {
        if (StringUtils.isEmpty(imei))
            return null;
        
        FindImeiRequest request = new FindImeiRequest();
        request.setPlatform(CommonConstants.ES);
        request.setImei(imei);
        
        return this.getEsEquipment(request);
    }
    
    @Override
    public EquipmentEntity getEsEquipment(String imei, String serialNo, String status) throws SQLException {
        return dao.getEsEquipmentEntity(imei, serialNo, status);
    }
    
    private List<EquipmentEntity> getEsEquipment(FindImeiRequest request) throws Exception {
        try {
            Client client = ClientHelper.createClient();
            WebResource webResource = client.resource(CommonConstants.ES_API_BASE_URL + CommonConstants.FIND_IMEI);
            ClientResponse response = (ClientResponse) webResource.type(CommonConstants.CONTENT_TYPE)
                    .header("Authorization", "Basic " + CommonConstants.ES_AUTH_STRING_ENC)
                    .post(ClientResponse.class, new ObjectMapper().writeValueAsString(request));
            String resString = (String) response.getEntity(String.class);
            _logger.info("resString = " + resString);
            EsMobileResponse esMobileResponse = new ObjectMapper().readValue(resString, EsMobileResponse.class);
            
            if (esMobileResponse != null) {
                
                List<EquipmentEntity> list = esMobileResponse.getImeiList();
                
                for (EquipmentEntity entity: list) {
                    EquipmentEntity ei2 = this.getEsEquipment(entity.getImei(), entity.getSerialNo(), null);
                    entity.setDescChi(ei2.getDescChi());
                    entity.setDescEng(ei2.getDescEng());
                    entity.setItemId(ei2.getItemId());
                    entity.setPartNo(ei2.getPartNo());
                }
                
                return list;
            }
        } catch(IOException ioe) {
            throw new Exception(ioe.getMessage());
        }
        return null;
    }
    
    @Override
    public String updateEquipment(ReplaceUpdateEntity entity) throws Exception {
        CreateOrder2Entity createOrder2Entity = new CreateOrder2Entity();
        createOrder2Entity.setInChannel1(entity.getPlatform());
        createOrder2Entity.setInChannel2("CS_PORTAL");
        createOrder2Entity.setInChannelRefNo(Long.toString(System.currentTimeMillis()));
        createOrder2Entity.setInPps(entity.getPps());
        createOrder2Entity.setInOrderType("REPLACE");
        createOrder2Entity.setInStatus(CommonConstants.CODE_0);
        createOrder2Entity.setInItemId1(entity.getItemId());
        createOrder2Entity.setInItemType1("OLD");
        createOrder2Entity.setInSerialNo1(entity.getOldImei());
        createOrder2Entity.setInItemId2(entity.getItemId());
        createOrder2Entity.setInItemType2("NEW");
        createOrder2Entity.setInSerialNo2(entity.getNewImei());
        createOrder2Entity.setInStaffCreate("HKBN");
        
        String outMessage = expressService.createOrder(createOrder2Entity);
        if (outMessage == null) {
            String resultMsg = this.replaceEquip(entity);
            if ("1".equals(resultMsg)) {
                logActionService.createRemarkAction(entity);
                return "SUCCESS";
            } else {
                return resultMsg;
            }
        } else {
            return outMessage;
        }
    }

    private String replaceEquip(ReplaceUpdateEntity entity) throws Exception {
        try {
            if (CommonConstants.RES.equals(entity.getPlatform())) {
                //RES call:Billing redemption procedure: OMDB HKBN_SCHEMA.pkg_brx_service_equip.p_replace_equip
                BillingReplaceEntity billingReplaceEntity = new BillingReplaceEntity();
                
                billingReplaceEntity.setServiceType("GPWF");
                billingReplaceEntity.setServiceCode(dao.getServiceNobyImei(entity.getOldImei()));
                billingReplaceEntity.setEquipType("H");
                billingReplaceEntity.setOldSerialNo(entity.getOldImei());
                billingReplaceEntity.setNewSerialNo(entity.getNewImei());
                billingReplaceEntity.setShopNo(entity.getShopNo());
                billingReplaceEntity.setStaffAmend(StringUtils.isNotEmpty(entity.getSalesName()) ? entity.getSalesName() : "HKBN");
                
                return dao.replaceEquip(billingReplaceEntity);

            } else if (CommonConstants.ES.equals(entity.getPlatform())) {
                //ES call
                List<ReplaceUpdateEntity> imeiList = new ArrayList<>();
                imeiList.add(entity);
                return this.updateImei(imeiList);

            } else {
                //other
                return null;
            }

        } catch (SQLException ex) {
            _logger.info(ex.getMessage());
            throw ex;
        }
    }

    private String updateImei(List<ReplaceUpdateEntity> list) throws Exception {
        UpdateImeiRequest request = new UpdateImeiRequest();
        request.setImeiList(list);
        String message = "error";
        try {

            Client client = ClientHelper.createClient();
            WebResource webResource = client.resource(CommonConstants.ES_API_BASE_URL + CommonConstants.UPDATE_IMEI);

            ClientResponse response = (ClientResponse) webResource.type(CommonConstants.CONTENT_TYPE)
                    .header("Authorization", "Basic " + CommonConstants.ES_AUTH_STRING_ENC)
                    .post(ClientResponse.class, new ObjectMapper().writeValueAsString(request));

            String resString = (String) response.getEntity(String.class);
            EsMobileResponse esMobileResponse = new ObjectMapper()
                    .readValue(resString, EsMobileResponse.class);

            if (null != esMobileResponse) {
                message = esMobileResponse.getMessageEnglish();
                if (CommonConstants.SUCCESS.equals(esMobileResponse.getResultCode())) {
                    message = CommonConstants.SUCCESS;
                }
            }
        } catch (ClientHandlerException | UniformInterfaceException | IOException ex) {
            _logger.error(ex.getMessage());
            throw ex;
        }
        return message;
    }
 
    @Override
    public Map<String, Picture> getPictureMap(List<String> itemIdList) throws SQLException {
        return dao.getPictureMap(itemIdList);
    }
    
    @Override
    public Picture getPicture(String itemId) throws SQLException {
        return dao.getPicture(itemId);
    }
    
    @Override
    public String getDummyItemId() throws SQLException {
        return dao.getDummyItemId();
    }
    
    
    // Copied from EsMobileService
//    @Override
//    public ReplacementCheckEntity esCheckNewImei(String platform, String pps, String imei, String brno) {
//      ReplacementCheckRequest request = new ReplacementCheckRequest();
//      request.setBrno(brno);
//      request.setImei(imei);
//      request.setPlatform(platform);
//      request.setPps(pps);
//      ReplacementCheckEntity replacementCheckEntity = new ReplacementCheckEntity();
//      replacementCheckEntity.setResultCode(CommonConstants.CODE_0);
//      replacementCheckEntity.setMessageEnglish("error");
//      Client client = ClientHelper.createClient();
//      WebResource webResource = client.resource(CommonConstants.ES_API_BASE_URL + CommonConstants.CHECK_IMEI + "/" + request.getImei());
//
//      try {
//
//        String response = webResource.header("content-text", "application/json")
//            .header("Authorization", "Basic " + CommonConstants.ES_AUTH_STRING_ENC).get(String.class);
//
//        EsMobileResponse esMobileResponse = new ObjectMapper().readValue(response, EsMobileResponse.class);
//
//          if (null != esMobileResponse) {
//            _logger.info(" ES API-check New imei response - ResultCode: " + esMobileResponse.getResultCode()+"-status:"+esMobileResponse.getStatus());
//
//            if (StringUtils.isNotEmpty(esMobileResponse.getMessageEnglish())) {
//              replacementCheckEntity.setMessageEnglish(esMobileResponse.getMessageEnglish());
//            }
//            if (StringUtils.isNotEmpty(esMobileResponse.getMessageChinese())) {
//              replacementCheckEntity.setMessageChinese(esMobileResponse.getMessageChinese());
//            }
//
//            if (CommonConstants.SUCCESS.equals(esMobileResponse.getResultCode()) && StringUtils
//                .equals("A",esMobileResponse.getStatus())) {
//              //es system has this new imei
//              replacementCheckEntity.setResultCode(CommonConstants.CODE_1);
//              replacementCheckEntity.setErrorCode(esMobileResponse.getErrorCode());
//              replacementCheckEntity.setMessageEnglish(CommonConstants.SUCCESS);
//            } else {
//              replacementCheckEntity.setResultCode("-104");
//              replacementCheckEntity.setMessageEnglish("es no equipment data");
//            }
//          }
//      } catch (JsonProcessingException e) {
//        e.printStackTrace();
//      } catch (IOException e) {
//        e.printStackTrace();
//      }
//      return replacementCheckEntity;
//    }
}
