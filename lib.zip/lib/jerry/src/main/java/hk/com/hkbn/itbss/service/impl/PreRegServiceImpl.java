/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.dao.PreRegDao;
import hk.com.hkbn.itbss.dao.impl.PreRegDaoImpl;
import hk.com.hkbn.itbss.entity.PreRegEntity;
import hk.com.hkbn.itbss.service.PreRegService;
import java.sql.SQLException;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor01
 */
@Stateless
@LocalBean
public class PreRegServiceImpl implements PreRegService {
    private final Logger _logger = LoggerFactory.getLogger(PreRegServiceImpl.class);
    
    @Resource(name = "jdbc.hkbn")
    private DataSource ds;
    
    private PreRegDao dao;
    
    public PreRegServiceImpl() {    
    }
    
    public PreRegServiceImpl(PreRegDao dao) {
        this.dao = dao;
    }
    
    @PostConstruct
    private void init() {
        this.dao = new PreRegDaoImpl(ds);
    }
    
    @Override
    public PreRegEntity getPreRegInfo(String preRegCode) throws SQLException {
        return dao.getPreRegInfo(preRegCode);
    }
    
}
