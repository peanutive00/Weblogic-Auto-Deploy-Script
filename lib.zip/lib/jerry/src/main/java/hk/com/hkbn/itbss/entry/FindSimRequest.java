/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 *
 * @author itbssvendor01
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "pps",
    "brno",
    "mobileLineNo",
    "sim"
})
public class FindSimRequest {
    
    @JsonProperty("pps")
    private String pps;
    
    @JsonProperty("brno")
    private String brno;
    
    @JsonProperty("mobileLineNo")
    private String mobileLineNo;
    
    @JsonProperty("sim")
    private String sim;

    public String getPps() {
        return pps;
    }

    public void setPps(String pps) {
        this.pps = pps;
    }

    public String getBrno() {
        return brno;
    }

    public void setBrno(String brno) {
        this.brno = brno;
    }

    public String getMobileLineNo() {
        return mobileLineNo;
    }

    public void setMobileLineNo(String mobileLineNo) {
        this.mobileLineNo = mobileLineNo;
    }

    public String getSim() {
        return sim;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }
    
}
