package hk.com.hkbn.itbss.entry;

import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import java.util.List;

/**
 * @description:
 * @author: leon.cheung
 * @create: 18-04-2018
 **/
public class UpdateImeiRequest {

  private List<ReplaceUpdateEntity> imeiList;

  public List<ReplaceUpdateEntity> getImeiList() {
    return imeiList;
  }

  public void setImeiList(List<ReplaceUpdateEntity> imeiList) {
    this.imeiList = imeiList;
  }
}
