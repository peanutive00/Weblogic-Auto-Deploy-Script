/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.dao.EomDao;
import hk.com.hkbn.itbss.dao.impl.EomDaoImpl;
import hk.com.hkbn.itbss.entity.EomDetailEntity;
import hk.com.hkbn.itbss.entity.EomMasterEntity;
import hk.com.hkbn.itbss.service.EomService;
import java.sql.SQLException;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor01
 */
@Stateless
@LocalBean
public class EomServiceImpl implements EomService {
    
    private final Logger _logger = LoggerFactory.getLogger(EomServiceImpl.class);
    
    @Resource(name = "jdbc.hkbnng_omtest")
    private DataSource ds;
    
    private EomDao dao;
    
    public EomServiceImpl() {    
    }
    
    public EomServiceImpl(EomDao dao) {
        this.dao = dao;
    }
    
    @PostConstruct
    private void init() {
        this.dao = new EomDaoImpl(ds);
    }
    
    @Override
    public String createEom(EomMasterEntity master, EomDetailEntity detail, List<EomDetailEntity> subItemList) throws SQLException {
        return dao.createEom(master, detail, subItemList);
    }
    
}
