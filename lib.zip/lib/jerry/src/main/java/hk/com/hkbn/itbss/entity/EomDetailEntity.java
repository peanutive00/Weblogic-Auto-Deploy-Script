/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

/**
 *
 * @author itbssvendor01
 */
public class EomDetailEntity {
    
    private Integer eomDetailCode;
    private Integer eomCode;
    private String eoType1;
    private String eoCode1;
    private String serialNo1;
    private String eoType2;
    private String eoCode2;
    private String serialNo2;
    private Integer masterEomDetailCode;
    private Double chargeAmount;
    private String chargeFlag;
    private String userId;

    public Integer getEomDetailCode() {
        return eomDetailCode;
    }

    public void setEomDetailCode(Integer eomDetailCode) {
        this.eomDetailCode = eomDetailCode;
    }

    public Integer getEomCode() {
        return eomCode;
    }

    public void setEomCode(Integer eomCode) {
        this.eomCode = eomCode;
    }

    public String getEoType1() {
        return eoType1;
    }

    public void setEoType1(String eoType1) {
        this.eoType1 = eoType1;
    }

    public String getEoCode1() {
        return eoCode1;
    }

    public void setEoCode1(String eoCode1) {
        this.eoCode1 = eoCode1;
    }

    public String getSerialNo1() {
        return serialNo1;
    }

    public void setSerialNo1(String serialNo1) {
        this.serialNo1 = serialNo1;
    }

    public String getEoType2() {
        return eoType2;
    }

    public void setEoType2(String eoType2) {
        this.eoType2 = eoType2;
    }

    public String getEoCode2() {
        return eoCode2;
    }

    public void setEoCode2(String eoCode2) {
        this.eoCode2 = eoCode2;
    }

    public String getSerialNo2() {
        return serialNo2;
    }

    public void setSerialNo2(String serialNo2) {
        this.serialNo2 = serialNo2;
    }

    public Integer getMasterEomDetailCode() {
        return masterEomDetailCode;
    }

    public void setMasterEomDetailCode(Integer masterEomDetailCode) {
        this.masterEomDetailCode = masterEomDetailCode;
    }

    public Double getChargeAmount() {
        return chargeAmount;
    }

    public void setChargeAmount(Double chargeAmount) {
        this.chargeAmount = chargeAmount;
    }

    public String getChargeFlag() {
        return chargeFlag;
    }

    public void setChargeFlag(String chargeFlag) {
        this.chargeFlag = chargeFlag;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    
}
