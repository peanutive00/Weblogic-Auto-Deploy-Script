/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao;

import hk.com.hkbn.itbss.entity.BrxEomRefCodeEntity;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author itbssvendor01
 */ 
public interface BrxEomRefCodeDao {
    
    public List<BrxEomRefCodeEntity> getRefCodeList(String refType) throws SQLException;
    
    public List<BrxEomRefCodeEntity> find(BrxEomRefCodeEntity entity) throws SQLException;
    
}
