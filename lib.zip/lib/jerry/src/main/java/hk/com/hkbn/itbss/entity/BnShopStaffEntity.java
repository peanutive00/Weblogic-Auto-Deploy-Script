/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

import java.util.Date;

/**
 *
 * @author itbssvendor02
 */
public class BnShopStaffEntity {

    /**
     * Table information
     */
    public static final String TABLE_NAME = "bn_shop_staff";

    public static final String EMP_NO = "emp_no";

    public static final String SHOP_NO = "shop_no";

    public static final String LOGIN_ID = "login_id";

    public static final String STATUS = "status";

    public static final String CREATE_DATE = "create_date";

    public static final String STAFF_CREATE = "staff_create";

    public static final String AMEND_DATE = "amend_date";
    
    /**
     * Entity field
     */
    private String empNo;
    private Integer shopNo;
    private String loginId;
    private String status;
    private java.sql.Date createDate;
    private String staffCreate;
    private java.sql.Date amendDate;

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public Integer getShopNo() {
        return shopNo;
    }

    public void setShopNo(Integer shopNo) {
        this.shopNo = shopNo;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public Date getCreateDate(){
        return createDate;
    }
    
    public void setCreateDate(Date createDate){
        if(createDate != null)
            this.createDate = new java.sql.Date(createDate.getTime());
    }
    
    public String getStaffCreate() {
        return staffCreate;
    }

    public void setStaffCreate(String staffCreate) {
        this.staffCreate = staffCreate;
    }
    
    public Date getAmendDate(){
        return amendDate;
    }
    
    public void setAmendDate(Date amendDate){
        if(amendDate != null)
            this.amendDate = new java.sql.Date(amendDate.getTime());
    }
    
}
