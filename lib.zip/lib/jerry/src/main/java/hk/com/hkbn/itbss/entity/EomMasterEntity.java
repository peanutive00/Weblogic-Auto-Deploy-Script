/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

/**
 *
 * @author itbssvendor01
 */
public class EomMasterEntity {
    
    private Integer eomCode;
    private String eomChannel1;
    private String eomChannel2;
    private String eomChannelRefNo;
    private String eomType;
    private String remark;
    private String shopNo;
    private String status;
    private String userId;

    public Integer getEomCode() {
        return eomCode;
    }

    public void setEomCode(Integer eomCode) {
        this.eomCode = eomCode;
    }

    public String getEomChannel1() {
        return eomChannel1;
    }

    public void setEomChannel1(String eomChannel1) {
        this.eomChannel1 = eomChannel1;
    }

    public String getEomChannel2() {
        return eomChannel2;
    }

    public void setEomChannel2(String eomChannel2) {
        this.eomChannel2 = eomChannel2;
    }

    public String getEomChannelRefNo() {
        return eomChannelRefNo;
    }

    public void setEomChannelRefNo(String eomChannelRefNo) {
        this.eomChannelRefNo = eomChannelRefNo;
    }

    public String getEomType() {
        return eomType;
    }

    public void setEomType(String eomType) {
        this.eomType = eomType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getShopNo() {
        return shopNo;
    }

    public void setShopNo(String shopNo) {
        this.shopNo = shopNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    
}
