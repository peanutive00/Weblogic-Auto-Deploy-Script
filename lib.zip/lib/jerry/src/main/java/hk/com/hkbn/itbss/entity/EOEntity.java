/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

import java.util.List;

/**
 *
 * @author itbssvendor01
 */
public abstract class EOEntity {

    private String eoFor;
    private String eoValue;
    private String eoType;
    private String eoCode;
    private String eoDesc;
    private String serialNo;

    private Double chargeFee;
    private Boolean chargeFlag;
    
    private List<SubItem> subItems;
    private Picture picture;
    
    public String getEoFor() {
        return eoFor;
    }

    public void setEoFor(String eoFor) {
        this.eoFor = eoFor;
    }

    public String getEoValue() {
        return eoValue;
    }

    public void setEoValue(String eoValue) {
        this.eoValue = eoValue;
    }

    public String getEoType() {
        return eoType;
    }

    public void setEoType(String eoType) {
        this.eoType = eoType;
    }

    public String getEoCode() {
        return eoCode;
    }

    public void setEoCode(String eoCode) {
        this.eoCode = eoCode;
    }

    public String getEoDesc() {
        return eoDesc;
    }

    public void setEoDesc(String eoDesc) {
        this.eoDesc = eoDesc;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public Double getChargeFee() {
        return chargeFee;
    }

    public void setChargeFee(Double chargeFee) {
        this.chargeFee = chargeFee;
    }

    public Boolean getChargeFlag() {
        return chargeFlag;
    }

    public void setChargeFlag(Boolean chargeFlag) {
        this.chargeFlag = chargeFlag;
    }
    
    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }

    public List<SubItem> getSubItems() {
        return subItems;
    }

    public void setSubItems(List<SubItem> subItems) {
        this.subItems = subItems;
    }
    
    @Override
    public String toString() {
        return "eoFor = " + eoFor +
               ", eoValue = " + eoValue +
               ", eoType = " + eoType +
               ", eoCode = " + eoCode +
               ", eoDesc = " + eoDesc +
               ", serialNo = " + serialNo;
    }
}
