/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import hk.com.hkbn.itbss.constants.CommonConstants;
import hk.com.hkbn.itbss.entity.EquipmentEntity;
import hk.com.hkbn.itbss.entry.FindSimRequest;
import hk.com.hkbn.itbss.entry.ReplaceSimRequest;
import hk.com.hkbn.itbss.httpClient.ClientHelper;
import hk.com.hkbn.itbss.service.SimService;
import hk.com.hkbn.itbss.service.URLService;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author itbssvendor01
 */
@Stateless
@LocalBean
public class SimServiceImpl implements SimService {
    
    private org.slf4j.Logger _logger = org.slf4j.LoggerFactory.getLogger(SimServiceImpl.class);
    
    @EJB
    private URLService urlService;
    
    @Override
    public List<EquipmentEntity> findSim(String pps, String brno, String mobileLineNo, String sim) {
        String url = null;
        try {
            url = urlService.getWebServiceURL(CommonConstants.ES_REF_TYPE, CommonConstants.FIND_SIM_REF_CODE);
        } catch(SQLException e) {
            _logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        List<EquipmentEntity> eiList = new ArrayList<>();
        
        FindSimRequest request = new FindSimRequest();
        request.setPps(pps);
        request.setBrno(brno);
        request.setMobileLineNo(mobileLineNo);
        request.setSim(sim);
        
        try {
            Client client = ClientHelper.createClient();
            WebResource webResource = client.resource(url);
            ClientResponse response = (ClientResponse) webResource.type("application/json")
                    .header("Authorization", "Basic " + CommonConstants.ES_AUTH_STRING_ENC)
                    .post(ClientResponse.class, new ObjectMapper().writeValueAsString(request));
            String jsonStr = (String) response.getEntity(String.class);
            JSONObject jsonObj = new JSONObject(jsonStr);
            JSONArray jsonArray = new JSONArray();
            if (jsonObj.has("imeiList")) {
                jsonArray = jsonObj.getJSONArray("imeiList");
            }
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject eiJson = jsonArray.getJSONObject(i);
                EquipmentEntity ei = new ObjectMapper().readValue(eiJson.toString(), EquipmentEntity.class);
                eiList.add(ei);
            }
        } catch(JsonProcessingException e) {
            _logger.error(e.getMessage(), e);
            e.printStackTrace();
        } catch(IOException e) {
            _logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        
        return eiList;
    }
    
    @Override
    public String replaceSim(String mobileLineNoCode, String oldSim, String newSim, String shopNo) {
        String url = null;
        try {
            url = urlService.getWebServiceURL(CommonConstants.ES_REF_TYPE, CommonConstants.FIND_SIM_REF_CODE);
        } catch(SQLException e) {
            _logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        
        ReplaceSimRequest request = new ReplaceSimRequest();
        request.setMobileLineNoCode(mobileLineNoCode);
        request.setOldSim(oldSim);
        request.setNewSim(newSim);
        request.setShopNo(shopNo);
        
        try {
            Client client = ClientHelper.createClient();
            WebResource webResource = client.resource(url);
            ClientResponse response = (ClientResponse) webResource.type("application/json")
                    .header("Authorization", "Basic " + CommonConstants.ES_AUTH_STRING_ENC)
                    .post(ClientResponse.class, new ObjectMapper().writeValueAsString(request));
            String jsonStr = (String) response.getEntity(String.class);
            JSONObject jsonObj = new JSONObject(jsonStr);
            if (jsonObj.has("resultCode"))
                return jsonObj.getString("resultCode");
        } catch(JsonProcessingException e) {
            _logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        
        return null;
    }
    
}
