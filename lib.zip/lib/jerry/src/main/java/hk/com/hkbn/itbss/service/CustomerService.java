package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.CustomerEntity;
import javax.ejb.Local;

/**
 * @description:
 * @author: leon.cheung
 * @create: 25-04-2018
 **/
@Local
public interface CustomerService {

  CustomerEntity getCusInfo(String pps);
}
