/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entry;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 *
 * @author itbssvendor01
 */
@JsonPropertyOrder({
    "pps",
    "imei",
    "brno"
})
public class FindImeiRequest {
        
    @JsonProperty("platform")
    private String platform;

    @JsonProperty("pps")
    private String pps;
        
    @JsonProperty("imei")
    private String imei;
        
    @JsonProperty("brno")
    private String brno;

    @JsonProperty("platform")
    public String getPlatform() {
        return platform;
    }

    @JsonProperty("platform")
    public void setPlatform(String platform) {
        this.platform = platform;
    }

    @JsonProperty("pps")
    public String getPps() {
        return pps;
    }

    @JsonProperty("pps")
    public void setPps(String pps) {
        this.pps = pps;
    }

    @JsonProperty("imei")
    public String getImei() {
        return imei;
    }

    @JsonProperty("imei")
    public void setImei(String imei) {
        this.imei = imei;
    }

    @JsonProperty("brno")
    public String getBrno() {
        return brno;
    }

    @JsonProperty("brno")
    public void setBrno(String brno) {
        this.brno = brno;
    }
    
}
