package hk.com.hkbn.itbss.service.impl;

import hk.com.hkbn.itbss.constants.CommonConstants;
import hk.com.hkbn.itbss.dao.LogActionDao;
import hk.com.hkbn.itbss.dao.impl.LogActionDaoImpl;
import hk.com.hkbn.itbss.entity.CustomerEntity;
import hk.com.hkbn.itbss.entity.ReplaceUpdateEntity;
import hk.com.hkbn.itbss.service.CustomerService;
import hk.com.hkbn.itbss.service.LogActionService;
import java.sql.SQLException;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

/**
 * @description:
 * @author: leon.cheung
 * @create: 03-05-2018
 **/
@Stateless
@LocalBean
public class LogActionServiceImpl implements LogActionService {


  private org.slf4j.Logger _logger = org.slf4j.LoggerFactory
      .getLogger(hk.com.hkbn.itbss.service.impl.LogActionServiceImpl.class);

  @Resource
  private EJBContext ctx;

  @Resource(name = "jdbc.hkbn")
  private DataSource ds;

  private LogActionDao dao;

  @EJB
  private CustomerService customerService;

  public LogActionServiceImpl() {

  }

  public LogActionServiceImpl(LogActionDao dao) {
    this.dao = dao;
  }

  @PostConstruct
  private void init() {
    this.dao = new LogActionDaoImpl(ds);
  }


  @Override
  public void createRemarkAction(ReplaceUpdateEntity entity) {
    CustomerEntity customerEntity = customerService.getCusInfo(entity.getPps());
    Long cusPriCode = customerEntity.getCusPriCode();
    //replacement fixed value
    int caseCode = 488;
    //remark sample :CUS CHG DEVICE DESC: (CHI_DES), FROM: (OLD IMEI) TO: (NEW IMEI), CHARGE OPTION: (OPTION), BY: (CREATE LOGIN ID), ON: (CREATE DATE)
    //remark sample :CUS CHG DEVICE (DESC: GMS1GD/SO GlocalMe Inside World Phone S1 32GB 金色 - PP), FROM: IMEI 867722030106241 TO: IMEI 867722030155670, CHARGE OPTION: (OPTION), BY: ALANM, ON: 2018/04/30
    StringBuilder remark = new StringBuilder();
    remark.append("CUS CHG DEVICE (DESC: ");
    remark.append(entity.getDesc());
    remark.append("), FROM: IMEI ");
    remark.append(entity.getOldImei());
    remark.append(" TO: IMEI ");
    remark.append(entity.getNewImei());
    remark.append(", CHARGE OPTION: (");
    remark.append(CommonConstants.chargeOptionMap.get(entity.getChargeOption()));
    remark.append("), BY: ");
    remark.append(entity.getSalesName());
    remark.append(", ON: ");
    remark.append(DateFormatUtils.format(new Date(),"yyyy/MM/dd"));

    try {
      String result = dao.createRemarkAction(cusPriCode, caseCode, remark.toString(), entity.getSalesName());
      if (StringUtils.isNotEmpty(result)) {
        _logger.info("repalcement API createLogAction: "+result);
      }

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}
