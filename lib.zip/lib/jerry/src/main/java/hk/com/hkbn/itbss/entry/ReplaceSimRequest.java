/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entry;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 *
 * @author itbssvendor01
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "mobileLineNoCode",
    "oldSim",
    "newSim",
    "shopNo"
})
public class ReplaceSimRequest {
    
    @JsonProperty("mobileLineNoCode")
    private String mobileLineNoCode;
    
    @JsonProperty("oldSim")
    private String oldSim;
    
    @JsonProperty("newSim")
    private String newSim;
    
    @JsonProperty("shopNo")
    private String shopNo;

    public String getMobileLineNoCode() {
        return mobileLineNoCode;
    }

    public void setMobileLineNoCode(String mobileLineNoCode) {
        this.mobileLineNoCode = mobileLineNoCode;
    }

    public String getOldSim() {
        return oldSim;
    }

    public void setOldSim(String oldSim) {
        this.oldSim = oldSim;
    }

    public String getNewSim() {
        return newSim;
    }

    public void setNewSim(String newSim) {
        this.newSim = newSim;
    }

    public String getShopNo() {
        return shopNo;
    }

    public void setShopNo(String shopNo) {
        this.shopNo = shopNo;
    }

}
