/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.BnShopStaffDao;
import hk.com.hkbn.itbss.entity.BnShopStaffEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author itbssvendor02
 */
public class BnShopStaffDaoImpl implements BnShopStaffDao {
    
    private final Logger _logger = LoggerFactory.getLogger(BnShopStaffDaoImpl.class);
    
    private final DataSource ds;

    public BnShopStaffDaoImpl(DataSource ds) {
        this.ds = ds;
    }

    @Override
    public String findStaffShopNo(String loginId) throws SQLException {
        
        String result = "";
        
        Connection connection = null;
        
        try{
            
            connection = ds.getConnection();
            
            String sql = "Select " + BnShopStaffEntity.SHOP_NO + " from " + BnShopStaffEntity.TABLE_NAME + " where " + BnShopStaffEntity.LOGIN_ID  + " = ? and " + BnShopStaffEntity.STATUS + " = \'A\' ";
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, loginId);
            
            ResultSet rs = statement.executeQuery();
            
            if(rs.next())
                result = rs.getString(BnShopStaffEntity.SHOP_NO);
            
            
        }catch(SQLException ex){
            _logger.error(ex.getMessage());
            return "";
        }finally{
            connection.close();
        }
        
        return result;
        
    }
    
}
