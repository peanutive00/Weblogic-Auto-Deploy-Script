/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.service;

import hk.com.hkbn.itbss.entity.EquipmentEntity;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author itbssvendor01
 */
@Local
public interface SimService {
    
    public List<EquipmentEntity> findSim(String pps, String brno, String mobileLineNo, String sim);
    
    public String replaceSim(String mobileLineNoCode, String oldSim, String newSim, String shopNo);
    
}
