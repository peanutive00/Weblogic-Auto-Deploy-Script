package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.LogActionDao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import javax.sql.DataSource;

/**
 * @description:
 * @author: leon.cheung
 * @create: 03-05-2018
 **/
public class LogActionDaoImpl implements LogActionDao{
  private org.slf4j.Logger _logger = org.slf4j.LoggerFactory.getLogger(LogActionDaoImpl.class);

  private final DataSource ds;

  public LogActionDaoImpl(DataSource ds) {
    this.ds = ds;
  }


  @Override
  public String createRemarkAction(Long cusPriCode, int caseCode, String remark, String userName)
      throws SQLException {
    String sql = "{call ices_handle_action_pkg.f_create_ices_remark_action(?, ?, ?, ?, ?)}";
    CallableStatement cst = null;
    Connection conn = null;
    String result = "";

    try {
      conn = ds.getConnection();
      cst = conn.prepareCall(sql);
      cst.setLong(1, cusPriCode);
      cst.setInt(2, caseCode);
      cst.setString(3, remark);
      cst.setString(4, userName);
      cst.registerOutParameter(5, Types.VARCHAR);
      cst.execute();

      result = cst.getString(5);

    } finally {
      try {
        if (cst != null) {
          cst.close();
        }
        if (conn != null) {
          conn.close();
        }
      } catch (Exception e) {
        cst = null;
        conn = null;
      }
    }
    return result;
  }
}
