/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.dao.impl;

import hk.com.hkbn.itbss.dao.ExpressDao;
import hk.com.hkbn.itbss.entity.CreateOrder2Entity;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author itbssvendor02
 */
public class ExpressDaoImpl implements ExpressDao {

    private final Logger _logger = LoggerFactory.getLogger(ExpressDaoImpl.class);
    private final DataSource ds;

    public ExpressDaoImpl(DataSource ds) {
        this.ds = ds;
    }

    @Override
    public String createOrder(CreateOrder2Entity createOrder2Entity) throws SQLException {

        CallableStatement cst = null;
        Connection connection = null;
        try {

            connection = ds.getConnection();

            String proc = "{call pkg_hkex.p_create_order(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

            cst = connection.prepareCall(proc);

            cst.setString(1, createOrder2Entity.getInChannel1());
            cst.setString(2, createOrder2Entity.getInChannel2());
            cst.setString(3, createOrder2Entity.getInChannelRefNo());
            cst.setString(4, createOrder2Entity.getInPps());
            cst.setString(5, createOrder2Entity.getInOrderDate());
            cst.setString(6, createOrder2Entity.getInOrderTimeFrame());
            cst.setString(7, createOrder2Entity.getInAddr1());
            cst.setString(8, createOrder2Entity.getInAddr2());
            cst.setString(9, createOrder2Entity.getInAddr3());
            cst.setString(10, createOrder2Entity.getInAddr4());
            cst.setString(11, createOrder2Entity.getInDistrictCode());
            cst.setString(12, createOrder2Entity.getInContactName());
            cst.setString(13, createOrder2Entity.getInContactTel());
            cst.setString(14, createOrder2Entity.getInOrderType());
            cst.setString(15, createOrder2Entity.getInAlertMsg());
            cst.setString(16, createOrder2Entity.getInStatus());
            cst.setString(17, createOrder2Entity.getInAddressCode());
            cst.setString(18, createOrder2Entity.getInFloor());
            cst.setString(19, createOrder2Entity.getInFlat());
            cst.setString(20, createOrder2Entity.getInStaffCreate());
            cst.setString(21, createOrder2Entity.getInSalesCode());
            cst.setString(22, createOrder2Entity.getInShopNo());
            cst.setString(23, createOrder2Entity.getInWaiveFlag());
            cst.setString(24, createOrder2Entity.getInChargeAmount());
            cst.setString(25, createOrder2Entity.getInQuotaReserverRef());
            cst.setString(26, createOrder2Entity.getInAuthCode());
            cst.setString(27, createOrder2Entity.getInItemId1());
            cst.setString(28, createOrder2Entity.getInItemCode1());
            cst.setString(29, createOrder2Entity.getInModel1());
            cst.setString(30, createOrder2Entity.getInVersion1());
            cst.setString(31, createOrder2Entity.getInOfferCode1());
            cst.setString(32, createOrder2Entity.getInQty1());
            cst.setString(33, createOrder2Entity.getInItemType1());
            cst.setString(34, createOrder2Entity.getInServiceType1());
            cst.setString(35, createOrder2Entity.getInSerialNo1());
            cst.setString(36, createOrder2Entity.getInItemId2());
            cst.setString(37, createOrder2Entity.getInItemCode2());
            cst.setString(38, createOrder2Entity.getInModel2());
            cst.setString(39, createOrder2Entity.getInVersion2());
            cst.setString(40, createOrder2Entity.getInOfferCode2());
            cst.setString(41, createOrder2Entity.getInQty2());
            cst.setString(42, createOrder2Entity.getInItemType2());
            cst.setString(43, createOrder2Entity.getInServiceType2());
            cst.setString(44, createOrder2Entity.getInSerialNo2());
            cst.setString(45, createOrder2Entity.getInItemId3());
            cst.setString(46, createOrder2Entity.getInItemCode3());
            cst.setString(47, createOrder2Entity.getInModel3());
            cst.setString(48, createOrder2Entity.getInVersion3());
            cst.setString(49, createOrder2Entity.getInOfferCode3());
            cst.setString(50, createOrder2Entity.getInQty3());
            cst.setString(51, createOrder2Entity.getInItemType3());
            cst.setString(52, createOrder2Entity.getInServiceType3());
            cst.setString(53, createOrder2Entity.getInSerialNo3());
            cst.setString(54, createOrder2Entity.getInItemId4());
            cst.setString(55, createOrder2Entity.getInItemCode4());
            cst.setString(56, createOrder2Entity.getInModel4());
            cst.setString(57, createOrder2Entity.getInVersion4());
            cst.setString(58, createOrder2Entity.getInOfferCode4());
            cst.setString(59, createOrder2Entity.getInQty4());
            cst.setString(60, createOrder2Entity.getInItemType4());
            cst.setString(61, createOrder2Entity.getInServiceType4());
            cst.setString(62, createOrder2Entity.getInSerialNo4());
            cst.setString(63, createOrder2Entity.getInItemId5());
            cst.setString(64, createOrder2Entity.getInItemCode5());
            cst.setString(65, createOrder2Entity.getInModel5());
            cst.setString(66, createOrder2Entity.getInVersion5());
            cst.setString(67, createOrder2Entity.getInOfferCode5());
            cst.setString(68, createOrder2Entity.getInQty5());
            cst.setString(69, createOrder2Entity.getInItemType5());
            cst.setString(70, createOrder2Entity.getInServiceType5());
            cst.setString(71, createOrder2Entity.getInSerialNo5());
            cst.registerOutParameter(72, Types.VARCHAR);

            cst.execute();

            return cst.getString(72);

        } finally {
            if (cst != null)
                cst.close();
            if (connection != null)
                connection.close();
        }
    }
}
