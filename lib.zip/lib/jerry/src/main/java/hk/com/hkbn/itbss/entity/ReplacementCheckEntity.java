/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hk.com.hkbn.itbss.entity;

import java.util.List;

/**
 * @author itbssvendor02
 */

/**
 * @Description: this is entity for plan filter response
 * @Author: leon.cheung
 * @Date: 3/20/2018
 */
public class ReplacementCheckEntity {

  private String resultCode;
  private String errorCode;
  private String messageEnglish;
  private String messageChinese;
  private String pps;
  private String cusName;
  private String cusStatus;
  private List<EquipmentEntity> equipList;

  public String getResultCode() {
    return resultCode;
  }

  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public String getMessageEnglish() {
    return messageEnglish;
  }

  public void setMessageEnglish(String messageEnglish) {
    this.messageEnglish = messageEnglish;
  }

  public String getMessageChinese() {
    return messageChinese;
  }

  public void setMessageChinese(String messageChinese) {
    this.messageChinese = messageChinese;
  }

  public String getPps() {
    return pps;
  }

  public void setPps(String pps) {
    this.pps = pps;
  }

  public String getCusName() {
    return cusName;
  }

  public void setCusName(String cusName) {
    this.cusName = cusName;
  }

  public String getCusStatus() {
    return cusStatus;
  }

  public void setCusStatus(String cusStatus) {
    this.cusStatus = cusStatus;
  }

  public List<EquipmentEntity> getEquipList() {
    return equipList;
  }

  public void setEquipList(List<EquipmentEntity> equipList) {
    this.equipList = equipList;
  }
  
  @Override
  public String toString() {
      String listStr = "";
      if (equipList != null) {
        for (EquipmentEntity ei: equipList) {
            if (listStr.length() == 0)
                listStr += "[" + ei.toString() + "]";
            else
                listStr += ", [" + ei.toString() + "]";
        }
      }
      String str = "resultCode = " + resultCode
                 + ", errorCode = " + errorCode
                 + ", messageEnglish = " + messageEnglish
                 + ", messageChinese = " + messageChinese
                 + ", pps = " + pps
                 + ", cusName = " + cusName
                 + ", cusStatus = " + cusStatus
                 + ", {" + listStr + "}";
      return str;
  }

}
